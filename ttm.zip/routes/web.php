<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\UserController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\SubjectController;
use App\Http\Controllers\TimeTableController;
use App\Http\Controllers\LectureController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\LectureHallController;
use App\Http\Controllers\KeeperController;




use App\Models\TimeTable;
use App\Events\TimeTableEvent;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});

Route::group(['middleware' => 'auth'], function() {

    Route::resource('department', DepartmentController::class);
    Route::resource('courses', CourseController::class);
    Route::resource('user', UserController::class);
    Route::resource('subjects', SubjectController::class);
    Route::resource('timetable', TimeTableController::class);
    Route::resource('lecturehall', LectureHallController::class);
    
    Route::get('/admin/report/', [AdminController::class, 'report'])->name('admin.report');

    Route::get('/profile', [UserController::class, 'profile'])->name('profile');
    Route::put('/user/changepassword/{user}', [UserController::class, 'updatePassword'])->name('changepassword');

    Route::get('lecture/show/{id}', [LectureController::class, 'show']);
    Route::get('lecture/lecturetimetable', [LectureController::class, 'report'])->name('lecture.lecturetimetable');
    Route::get('lecture/summaryreport', [LectureController::class, 'summaryReport'])->name('lecture.summaryreport');
    Route::get('lecture/download', [LectureController::class, 'download'])->name('lecture.download');

    Route::get('student/report/{id}', [StudentController::class, 'report'])->name('student.report');

    Route::get('hallkeeper/keepertimetable', [KeeperController::class, 'report'])->name('hallkeeper.report');
    Route::get('hallkeeper/generate', function() { return redirect()->route('hallkeeper.report'); });
    Route::post('hallkeeper/generate', [KeeperController::class, 'generate'])->name('hallkeeper.generate');
    
    Route::get('hallkeeper/subject_report', function() { return redirect()->route('hallkeeper.report'); });

    
    Route::get('lecture/tables', [LectureController::class, 'tables']);

    Route::get('/dashboard', [UserController::class, 'dashboard'])->name('dashboard');
});























