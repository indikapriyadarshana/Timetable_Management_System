<footer class="footer">
  <div class=" container-fluid ">
    <div class="copyright" id="copyright">
      &copy;
      <script>
        document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))
      </script>,UNIVOTEC TimeTable Management System

    </div>
  </div>
</footer><?php /**PATH D:\ttm\resources\views/layouts/footer.blade.php ENDPATH**/ ?>