<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-transparent  bg-primary  navbar-absolute">
  <div class="container-fluid">
    <div class="navbar-wrapper">
    <a class="navbar-brand" href="#pablo"><h3>UNIVOTEC</h3> TimeTable Management System</a>
    </div>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-bar navbar-kebab"></span>
      <span class="navbar-toggler-bar navbar-kebab"></span>
      <span class="navbar-toggler-bar navbar-kebab"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navigation">
      <ul class="navbar-nav">
        <?php if(auth()->guard()->check()): ?>
        <li class="nav-item">
          <a href="<?php echo e(route('dashboard')); ?>" class="nav-link">
            <i class="now-ui-icons design_app"></i> <?php echo e(__("Dashboard")); ?>

          </a>
        </li>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
              <?php echo csrf_field(); ?>
            </form>
        <li class="nav-item <?php if($activePage == 'logout'): ?> active <?php endif; ?> ">
          <a href="<?php echo e(route('logout')); ?>" class="nav-link" onclick="event.preventDefault();
                          document.getElementById('logout-form').submit();">
            <i class="now-ui-icons users_circle-08"></i> <?php echo e(__("Log out")); ?>

          </a>
        </li>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
        <li class="nav-item <?php if($activePage == 'register'): ?> active <?php endif; ?>">
          <a href="<?php echo e(route('register')); ?>" class="nav-link">
            <i class="now-ui-icons tech_mobile"></i> <?php echo e(__("Register")); ?>

          </a>
        </li>
        <li class="nav-item <?php if($activePage == 'login'): ?> active <?php endif; ?> ">
          <a href="<?php echo e(route('login')); ?>" class="nav-link">
            <i class="now-ui-icons users_circle-08"></i> <?php echo e(__("Login")); ?>

          </a>
        </li>
        <?php endif; ?>
        
      </ul>
    </div>
  </div>
</nav>
<!-- End Navbar --><?php /**PATH D:\Projects\Laravel Projects\Ongoing\TTMS\resources\views/layouts/navbars/navs/guest.blade.php ENDPATH**/ ?>