

<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row">
    <div class="col-md-13">
      <div class="card">
        <div class="card-header">
          <h5 class="title"><?php echo e(__(" Student Timetable")); ?></h5>
          <button id="download" class="btn btn-primary">Download</button>
        </div>
            <div class="container">
                <table id="timetable" class="table table-bordered text-center"> 
                    <tr>
                      <th>Day/Time</th>
                      <th>Monday</th>
                      <th>Tuesday</th>
                      <th>Wenday</th>
                      <th>Thursday</th>
                      <th>Friday</th>
                      <th>Saturday</th>
                      <th>Sunday</th>
                    </tr>
                     
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr> 
                          <td><b><?php echo e($key + 6); ?>. 00</b></td>
                          <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <td> 
                          <?php if( isset($row2['lecture_name'])): ?>
                          <span  class="badge badge-danger badge-pill"><?php echo e($row2['lecture_name']); ?></span><br>
                          <?php endif; ?>
                            <?php if( isset($row2['course_name'])): ?>
                          <span  class="badge badge-info badge-pill"><?php echo e($row2['course_name']); ?></span><br>
                          <?php endif; ?>
                          <p><?php echo e($row2['subject_code']); ?></p>
                        </td>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </table>
            </div>
      </div>
    </div>
  </div>
</div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startPush('js'); ?>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });

    $("#download").click(function() {
      //window.jsPDF = window.jspdf.jsPDF;
      var doc = new jsPDF('p', 'pt', 'a3');  
    var htmlstring = '';  
    var tempVarToCheckPageHeight = 0;  
    var pageHeight = 0;  
    pageHeight = doc.internal.pageSize.height;  
    specialElementHandlers = {  
        // element with id of "bypass" - jQuery style selector  
        '#bypassme': function(element, renderer) {  
            // true = "handled elsewhere, bypass text extraction"  
            return true  
        }  
    };  
    var y = 5;   
    doc.text(50, y = y + 30, "Time Table");
    doc.autoTable({  
        html: '#timetable',  
        startY: 70,  
        theme: 'grid',
    })  
    doc.save('reprot.pdf');
    });
  </script>
  <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'Timetable',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Education\School Project\TTMS\resources\views/student/report.blade.php ENDPATH**/ ?>