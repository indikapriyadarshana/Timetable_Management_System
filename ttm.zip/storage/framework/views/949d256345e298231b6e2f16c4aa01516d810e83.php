
<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content text-center ">
  <h1 class="text-primary">Time Table Management System</h1>
  
  <h5 class="text-primary">for better time management</h5>
  <?php if(auth()->guard()->check()): ?>
  <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary btn-round btn-lg">
    Get Start
  </a>
  <?php endif; ?>
  <?php if(auth()->guard()->guest()): ?>
  <a href="<?php echo e(route('login')); ?>" class="btn btn-primary btn-round btn-lg">
    Get Start
  </a>
  <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
  $(document).ready(function() {
    // Javascript method's body can be found in assets/js/demos.js
    demo.initDashboardPageCharts();

  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.guest', [
'namePage' => 'Dashboard',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Education\School Project\TTMS\resources\views/home.blade.php ENDPATH**/ ?>