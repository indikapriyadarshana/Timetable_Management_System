

<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h5 class="title"><?php echo e(__(" Report")); ?></h5>
        </div>
            <div class="card-body">
              <div id="accordion">

                <div class="card">               
                  <div class="card-header" id="headingOne">
                    <h5 class="mb-0">
                      <button class="btn btn-link" data-toggle="collapse" data-target="#collapse_userreport" aria-expanded="true" aria-controls="collapse_userreport">
                        Users Report
                      </button>
                    </h5>
                  </div>

                  <div id="collapse_userreport" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                  <div class="card-body">
                    <h6>Report</h6>
                    <div class="container" style="margin-left: -10px;">
                      <table class="table table-bordered text-center" style="table-layout: auto;">   
                      <tr>
                        <th>User Type</th>
                        <th>Count</th>
                        </tr>
                        <?php $__currentLoopData = $data['userreport']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <tr>
                          <td><?php echo e($row->slug); ?></td>
                          <td><?php echo e($row->count); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
                  </div>
                    </div>
                  </div>

                </div>

                <div class="card">               
                  <div class="card-header" id="headingOne">
                    <h5 class="mb-0">
                      <button class="btn btn-link" data-toggle="collapse" data-target="#collapse_lecturereport" aria-expanded="true" aria-controls="collapse_lecturereport">
                        Lectures Report
                      </button>
                    </h5>
                  </div>

                  <div id="collapse_lecturereport" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                  <div class="card-body">
                    <h6>Report</h6>
                    <div class="container" style="margin-left: -10px;">
                      <table class="table table-bordered text-center" style="table-layout: auto;">   
                      <tr>
                        <th>Lecture Name</th>
                        <th>Total Working Hours</th>
                        </tr>
                        <?php $__currentLoopData = $data['lecturereport']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <tr>
                          <td><?php echo e($value['name']); ?></td>
                          <td><?php echo e($value['count']); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
                  </div>
                    </div>
                  </div>

                </div>
          </div>
      </div>
    </div>
  </div>
</div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startPush('js'); ?>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });
  </script>
  <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'Summary Report',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Education\School Project\TTMS\resources\views/admin/report.blade.php ENDPATH**/ ?>