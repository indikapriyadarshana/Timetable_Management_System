

<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div id="app">
  <timetable-edit :table="<?php echo e($table); ?>" :subjects="<?php echo e($subjects); ?>" :lecturehalls="<?php echo e($lecturehalls); ?> " :user="<?php echo e($user); ?>" :lecturetable="<?php echo e($lecturetable); ?>"></timetable-edit>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.timetable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Education\School Project\TTMS\resources\views/timetable/edit.blade.php ENDPATH**/ ?>