

<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h5 class="title"><?php echo e($tables->first()->course->name); ?></h5>
        </div>
        <div class="card-body">
          <div id="accordion">
            
            <table class="table table-bordered text-center" style="table-layout: auto;">   
                <tr>
                  <th>Semester</th>
                  <th>View</th>
                  <th>Report</th>
                </tr>
                <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>Semester - <?php echo e($table->semester); ?></td>
                  <td><a href="<?php echo e(route('timetable.show', $table->id)); ?>">View</a></td>
                  <td><a href="<?php echo e(route('student.report', $table->id)); ?>">Report</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startPush('js'); ?>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });
  </script>
  <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'Time Tables',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ttm\resources\views/timetable/st_table.blade.php ENDPATH**/ ?>