

<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h5 class="title"><?php echo e(__(" Courses")); ?></h5>
        </div>


        <div class="card-body">
          <div id="accordion">
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
              <div class="card-header" id="headingOne">
                <h5 class="mb-0">
                  <button class="btn btn-link" data-toggle="collapse" data-target="#collapse<?php echo e($department->id); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($department->id); ?>">
                    <?php echo e($department->name); ?>

                  </button>
                </h5>
              </div>

              <div id="collapse<?php echo e($department->id); ?>" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                <div class="card-body">
                  
                  
                  <table class="table table-bordered text-center" style="table-layout: auto;">   
                      <tr>
                        <th>Course</th>
                        <th>Semester</th>
                        <th>View</th>
                        <?php if(auth()->user()->role->name === "lecture" || auth()->user()->role->name === "hall_keeper"): ?>
                        <th>Edit</th>
                        <?php endif; ?>
                        </tr>
                        
                        <?php $__currentLoopData = $department->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $course->timetable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($course->name); ?></td>
                            <td><?php echo e($table->semester); ?></td>
                            <td><a href="<?php echo e(route('timetable.show', $table->id)); ?>" target="_blank">View</a></td>
                            <?php if(auth()->user()->role->name === "lecture" || auth()->user()->role->name === "hall_keeper"): ?>
                            <td><a href="<?php echo e(route('timetable.edit', $table->id)); ?>">Edit</a></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </table>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startPush('js'); ?>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });
  </script>
  <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'Dashboard',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Education\School Project\TTMS\resources\views/timetable/tables.blade.php ENDPATH**/ ?>