

<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row justify-content-md-center">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h2 class="title text-center"><?php echo e(__(" Welcome")); ?></h2>
        </div>
        <div class="card-body">
            <h3 class="text-center">UNIVOTEC TimeTable Management System </h3>
            <h5 class="text-center">Never leave till tomrrow which you can do today - Benjamin Franklin</h5>
            <h6 class="text-center">If you face any system issue please contact ICT center +941109865712</h6>
        </div>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
  $(document).ready(function() {
    // Javascript method's body can be found in assets/js/demos.js
    demo.initDashboardPageCharts();

  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'Dashboard',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Laravel Projects\Ongoing\TTMS\resources\views/dashboard.blade.php ENDPATH**/ ?>