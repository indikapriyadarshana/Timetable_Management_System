<?php if($errors->has($field)): ?>
    <span class="invalid-feedback" role="alert" style="display: block;">
        <strong><?php echo e($errors->first($field)); ?></strong>
    </span>
<?php endif; ?><?php /**PATH D:\Projects\Laravel Projects\Ongoing\TTMS\resources\views/alerts/feedback.blade.php ENDPATH**/ ?>