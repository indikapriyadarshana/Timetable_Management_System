

<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div id="app">
  <timetable-show :table="<?php echo e($table); ?>" :user="<?php echo e($user); ?>"></timetable-show>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.timetable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Education\School Project\TTMS\resources\views/timetable/show.blade.php ENDPATH**/ ?>