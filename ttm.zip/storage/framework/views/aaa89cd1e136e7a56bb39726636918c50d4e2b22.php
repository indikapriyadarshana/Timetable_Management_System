

<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h5 class="title"><?php echo e(__(" Courses")); ?></h5>
          <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>


        <div class="card-body">
          <div id="accordion">
            <h6>Add New Course</h6>
            <form method="post" action="<?php echo e(route('courses.store')); ?>" autocomplete="off" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="row">
              </div>
              <div class="row">
                <div class="col-md-7 pr-1">
                  <div class="form-group">
                    <label><?php echo e(__("Course Name")); ?></label>
                    <input type="text" name="name" class="form-control" value="">
                    <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-7 pr-1">
                  <div class="form-group">
                    <label><?php echo e(__(" Course Code")); ?></label>
                    <input type="text" name="course_code" class="form-control" value="">
                    <?php echo $__env->make('alerts.feedback', ['field' => 'course_code'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                </div>
              </div>


              <div class="row">
                <div class="col-md-7 pr-1">
                  <div class="form-group">
                    <label><?php echo e(__(" Course Details")); ?></label>
                    <textarea name="details" class="form-control" value=""></textarea>
                    <?php echo $__env->make('alerts.feedback', ['field' => 'details'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                </div>
              </div>

              <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label><?php echo e(__(" Department")); ?></label>
                  <select class="form-control" id="department_id" name="department_id" value="">
                  <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
            </div>

              <div class="row">
                <div class="col-md-7 pr-1">
                  <div class="form-group">
                    <label><?php echo e(__("Number of Semesters")); ?></label>
                    <select class="form-control" id="exampleFormControlSelect1" name="semester" value="">
                      <option value="2">2</option>
                      <option value="4">4</option>
                      <option value="6">6</option>
                      <option value="8">8</option>
                    </select>
                  </div>
                </div>
              </div>
              <div class="card-footer ">
                <button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Add Course')); ?></button>
              </div>
              <hr class="half-rule" />
            </form>

            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
              <div class="card-header" id="headingOne">
                <h5 class="mb-0">
                  <button class="btn btn-link" data-toggle="collapse" data-target="#collapse<?php echo e($department->id); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($department->id); ?>">
                    <?php echo e($department->name); ?>

                  </button>
                </h5>
              </div>

              <div id="collapse<?php echo e($department->id); ?>" class="collapse hide" aria-labelledby="headingOne" data-parent="#accordion">
                <div class="card-body">
                  <h5>Courses</h5>
                  
                  <?php $__currentLoopData = $department->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="d-flex justify-content-between" style="margin-top: 10px">
                    <h6><?php echo e($course->name); ?></h6>
                    <div class="d-flex justify-content-between">
                      <a class="btn btn-primary btn-round" href="<?php echo e(route('courses.edit', $course->id)); ?>">Edit</a>
                      <a class="btn btn-primary btn-round" href="<?php echo e(route('subjects.show', $course->id)); ?>">Manage Subjects</a>
                    </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startPush('js'); ?>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });
  </script>
  <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'COURSES',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Laravel Projects\Ongoing\TTMS\resources\views/course/index.blade.php ENDPATH**/ ?>