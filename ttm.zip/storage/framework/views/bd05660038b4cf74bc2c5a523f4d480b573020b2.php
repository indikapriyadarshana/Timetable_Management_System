<div class="sidebar" data-color="orange">
  <!--
    Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
-->
  <div class="logo">
    <a href="" class="simple-text logo-mini">
    <i class="now-ui-icons users_circle-08"></i>
    </a>
    <a href="" class="simple-text logo-normal">
      <?php echo e(auth()->user()->role->slug); ?>

    </a>
  </div>
  <div class="sidebar-wrapper" id="sidebar-wrapper">
    <ul class="nav">
      <li class="">
        <a href="<?php echo e(route('dashboard')); ?>">
          <i class="now-ui-icons design_app"></i>
          <p><?php echo e(__('Dashboard')); ?></p>
        </a>
      </li>
      <li>
      
      <?php if(auth()->user()->role->name !== "admin"): ?>
      <li class="">
        <a href="<?php echo e(route('timetable.index')); ?>">
          <i class="now-ui-icons design_bullet-list-67"></i>
          <p><?php echo e(__('Time Tables')); ?></p>
        </a>
      </li>
      <?php endif; ?>

      <?php if(auth()->user()->role->name === "admin"): ?>
      <li class="">
        <a href="<?php echo e(route('courses.index')); ?>">
          <i class="now-ui-icons files_single-copy-04"></i>
          <p> <?php echo e(__("Courses")); ?> </p>
        </a>
      </li>
      <?php endif; ?>

      <?php if(auth()->user()->role->name === "admin"): ?>
      <li class="">
        <a href="<?php echo e(route('department.index')); ?>">
          <i class="now-ui-icons education_hat"></i>
          <p> <?php echo e(__("Departments")); ?> </p>
        </a>
      </li>
      <?php endif; ?>

      <?php if(auth()->user()->role->name === "admin"): ?>
      <li class="">
        <a href="<?php echo e(route('user.index')); ?>">
          <i class="now-ui-icons users_single-02"></i>
          <p> <?php echo e(__("Users")); ?> </p>
        </a>
      </li>
      <?php endif; ?>

      <?php if(auth()->user()->role->name === "admin"): ?>
      <li class="">
        <a href="<?php echo e(route('lecturehall.index')); ?>">
          <i class="now-ui-icons business_bank"></i>
          <p> <?php echo e(__("Lecture Halls")); ?> </p>
        </a>
      </li>
      <?php endif; ?>

      <?php if(auth()->user()->role->name === "lecture"): ?>
      <li class="">
        <a href="<?php echo e(route('lecture.lecturetimetable')); ?>">
          <i class="now-ui-icons business_chart-bar-32"></i>
          <p> <?php echo e(__("Lecture Timetable")); ?> </p>
        </a>
      </li>
      <?php endif; ?>

      <?php if(auth()->user()->role->name === "hall_keeper"): ?>
      <li class="">
        <a href="<?php echo e(route('hallkeeper.report')); ?>">
          <i class="now-ui-icons business_chart-bar-32"></i>
          <p> <?php echo e(__("Report")); ?> </p>
        </a>
      </li>
      <?php endif; ?>

      <?php if(auth()->user()->role->name === "lecture"): ?>
      <li class="">
        <a href="<?php echo e(route('lecture.summaryreport')); ?>">
          <i class="now-ui-icons business_chart-pie-36"></i>
          <p> <?php echo e(__("Summary Report")); ?> </p>
        </a>
      </li>
      <?php endif; ?>

      <?php if(auth()->user()->role->name === "admin"): ?>
      <li class="">
        <a href="<?php echo e(route('admin.report')); ?>">
          <i class="now-ui-icons users_single-02"></i>
          <p> <?php echo e(__("Report")); ?> </p>
        </a>
      </li>
      <?php endif; ?>

    </ul>
  </div>
</div>
<?php /**PATH D:\Education\School Project\TTMS\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>