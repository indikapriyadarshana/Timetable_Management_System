

<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">


  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h5 class="title"><?php echo e(__(" Course Edit")); ?></h5>
        </div>
        <div class="card-body">
          <form method="post" action="<?php echo e(route('courses.update', $data->id)); ?>" autocomplete="off" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label><?php echo e(__("Course Name")); ?></label>
                  <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $data->name)); ?>">
                  <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label><?php echo e(__(" Course Code")); ?></label>
                  <input type="text" name="course_code" class="form-control" value="<?php echo e(old('course_code', $data->course_code)); ?>">
                  <?php echo $__env->make('alerts.feedback', ['field' => 'course_code'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label><?php echo e(__(" Course Details")); ?></label>
                  <textarea   name="details" class="form-control"><?php echo e(old('details', $data->details)); ?></textarea>
                  <?php echo $__env->make('alerts.feedback', ['field' => 'details'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              </div>
            </div>
            <input type="hidden" name="department_id" value="<?php echo e($data->department_id); ?>">
            <div class="card-footer ">
              <button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Update')); ?></button>
            </div>
            <hr class="half-rule" />
          </form>
        </div>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
  $(document).ready(function() {
    // Javascript method's body can be found in assets/js/demos.js
    demo.initDashboardPageCharts();

  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'Dashboard',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ttm\resources\views/course/edit.blade.php ENDPATH**/ ?>