

<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h5 class="title"><?php echo e(__(" Departments")); ?></h5>
        </div>
        <div class="card-body">
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="d-flex justify-content-between">
            <h5><?php echo e($department->name); ?></h5>
            <a class="btn btn-primary btn-round" href="<?php echo e(route('department.edit',$department->id)); ?>">Edit</a>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="card card-user">
      <div class="card-header">
        <h5 class="title"><?php echo e(__(" Add New Department")); ?></h5>
      </div>
      <div class="card-body">
        <form method="post" action="<?php echo e(route('department.store')); ?>" autocomplete="off" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="row">
          </div>
          <div class="row">
            <div class="col-md-7 pr-1">
              <div class="form-group">
                <label><?php echo e(__(" Name")); ?></label>
                <input type="text" name="name" class="form-control" value="">
                <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-7 pr-1">
              <div class="form-group">
                <label><?php echo e(__(" Department Code")); ?></label>
                <input type="text" name="dept_code" class="form-control" value="">
                <?php echo $__env->make('alerts.feedback', ['field' => 'dept_code'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-7 pr-1">
              <div class="form-group">
                <label><?php echo e(__(" Department Details")); ?></label>
                <textarea name="details" class="form-control" value=""></textarea>
                <?php echo $__env->make('alerts.feedback', ['field' => 'details'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
            </div>
          </div>
          

          <div class="card-footer ">
            <button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Add Department')); ?></button>
          </div>
          <hr class="half-rule" />
        </form>
      </div>
    </div>
  </div>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
  $(document).ready(function() {
    // Javascript method's body can be found in assets/js/demos.js
    demo.initDashboardPageCharts();

  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'Department',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ttm\resources\views/department/index.blade.php ENDPATH**/ ?>