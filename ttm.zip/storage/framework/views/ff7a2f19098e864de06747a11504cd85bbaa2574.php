

<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">


  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h5 class="title"><?php echo e(__(" Add New User")); ?></h5>
        </div>
        <div class="card-body">
          <form method="post" action="<?php echo e(route('user.store', auth()->user()->id)); ?>" autocomplete="off" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label><?php echo e(__(" Name")); ?></label>
                  <input type="text" name="name" class="form-control" value="" placeholder="Name">
                  <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label for="exampleInputEmail1"><?php echo e(__(" Email address")); ?></label>
                  <input type="email" name="email" class="form-control" placeholder="Email" value="">
                  <?php echo $__env->make('alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label for="exampleInputEmail1"><?php echo e(__(" Contact number")); ?></label>
                  <input type="text" name="phone_no" class="form-control" placeholder="Phone" value="">
                  <?php echo $__env->make('alerts.feedback', ['field' => 'phone_no'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label><?php echo e(__(" Address")); ?></label>
                  <input type="text" name="address" class="form-control" value="" placeholder="Address">
                  <?php echo $__env->make('alerts.feedback', ['field' => 'address'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label><?php echo e(__(" User Role")); ?></label>
                  <select class="form-control" id="exampleFormControlSelect1" name="role_id" value="">
                  <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label><?php echo e(__(" Department")); ?></label>
                  <select class="form-control" id="department_id" name="department_id" value="">
                  <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group <?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                  <label><?php echo e(__(" Password")); ?></label>
                  <input class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('New Password')); ?>" type="password" name="password" required>
                  <?php echo $__env->make('alerts.feedback', ['field' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group <?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                  <label><?php echo e(__(" Confirm Password")); ?></label>
                  <input class="form-control" placeholder="<?php echo e(__('Confirm New Password')); ?>" type="password" name="password_confirmation" required>
                </div>
              </div>
            </div>
            <div class="card-footer ">
              <button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Save')); ?></button>
            </div>
            <hr class="half-rule" />
          </form>
        </div>
      </div>
    </div>
  </div>

  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h5 class="title"><?php echo e($role['slug']); ?></h5>
        </div>
        <div class="card-body">
          <?php $__currentLoopData = $role['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="d-flex justify-content-between">
            <h5><?php echo e($user->name); ?></h5>
            <a class="btn btn-primary btn-round" href="<?php echo e(route('user.edit',$user->id)); ?>">Edit</a>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  

  

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
  $(document).ready(function() {
    // Javascript method's body can be found in assets/js/demos.js
    demo.initDashboardPageCharts();

  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'Users',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Education\School Project\TTMS\resources\views/user/index.blade.php ENDPATH**/ ?>