

<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h3><?php echo e($course->name); ?></h3>
          <h5 class="title"> <?php echo e(__(" Subject")); ?></h5>
        </div>
        <div class="card-body">
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="d-flex justify-content-between">
            <h5><?php echo e($subject->subject_code); ?> - Semester <?php echo e($subject->semester); ?></h5>
            <a class="btn btn-primary btn-round" href="<?php echo e(route('subjects.edit',$subject->id)); ?>">Edit</a>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="card card-user">
      <div class="card-header">
        <h5 class="title"><?php echo e(__(" Add New Subject")); ?></h5>
      </div>
      <div class="card-body">
        <form method="post" action="<?php echo e(route('subjects.store')); ?>" autocomplete="off" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="row">
          </div>
          <div class="row">
            <div class="col-md-7 pr-1">
              <div class="form-group">
                <label><?php echo e(__(" Name")); ?></label>
                <input type="text" name="name" class="form-control" value="">
                <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-7 pr-1">
              <div class="form-group">
                <label><?php echo e(__(" Subject Code")); ?></label>
                <input type="text" name="subject_code" class="form-control" value="">
                <?php echo $__env->make('alerts.feedback', ['field' => 'subject_code'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
            </div>
          </div>

          <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label><?php echo e(__(" Semester")); ?></label>
                  <select class="form-control" id="exampleFormControlSelect1" name="semester" value="">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                  </select>
                </div>
              </div>
            </div>
          <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">
          <div class="card-footer ">
            <button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Add Subject')); ?></button>
          </div>
          <hr class="half-rule" />
        </form>
      </div>
    </div>
  </div>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
  $(document).ready(function() {
    // Javascript method's body can be found in assets/js/demos.js
    demo.initDashboardPageCharts();

  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'Dashboard',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Education\School Project\TTMS\resources\views/subject/show.blade.php ENDPATH**/ ?>