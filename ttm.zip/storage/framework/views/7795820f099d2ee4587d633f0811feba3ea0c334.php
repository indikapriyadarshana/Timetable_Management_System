

<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row">
    <div class="col-md-13">
      <div class="card">
        <div class="card-header">
          <h5 class="title"><?php echo e(__(" Keeper Timetable")); ?></h5>
          <form method="post" action="<?php echo e(route('hallkeeper.generate')); ?>">
          <?php echo csrf_field(); ?>
              <div class="form-row">

                <div class="form-group">
                  <label for="exampleInputEmail1" style="margin-top: 10px; margin-left:15px">Department: </label>
                </div>

                <div class="form-group"> 
                  <select class="form-control" id="department" name="department" style="margin-left:15px;">
                      <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department['id']); ?>"><?php echo e($department['name']); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>


                <div class="form-group" style="margin-left: 15px">
                  <label for="exampleInputEmail1" style="margin-top: 10px; margin-left:15px">Hall Code</label>
                </div>

                <div class="form-group"> 
                  <select class="form-control" id="hall_id" name="hall_id" style="margin-left:15px;">
                  <option value="" disabled selected>Select lecture hall</option>
                </select>
                </div>
                
                <div class="form-group" style="margin-left: 15px">
                  <input type="submit" class="btn btn-primary" value="Generate" style="margin-top: -1px; margin-left: 15px">
                </div>

                <div class="form-group">
                  <input type="button" id="download" class="btn btn-primary" style="margin-top: -1px; margin-left: 15px" value="Download"></input>
                </div>
              </div>
          </form>
          
        </div>
            <div class="container">
              <?php if(isset($tbl)): ?>
                <table id="timetable" class="table table-bordered text-center"> 
                    <tr>
                      <th>Day/Time</th>
                      <th>Monday</th>
                      <th>Tuesday</th>
                      <th>Wenday</th>
                      <th>Thursday</th>
                      <th>Friday</th>
                      <th>Saturday</th>
                      <th>Sunday</th>
                    </tr>
                     
                    <?php $__currentLoopData = $tbl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr> 
                          <td><b><?php echo e($key + 6); ?>. 00</b></td>
                          <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <td> 
                          <?php if( isset($row2['lecture_name'])): ?>
                          <span  class="badge badge-danger badge-pill"><?php echo e($row2['lecture_name']); ?></span><br>
                          <?php endif; ?>
                            <?php if( isset($row2['course_name'])): ?>
                          <span  class="badge badge-info badge-pill"><?php echo e($row2['course_name']); ?></span><br>
                          <?php endif; ?>
                          <p><?php echo e($row2['subject_code']); ?></p>
                        </td>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </table>
              <?php endif; ?>
            </div>
      </div>
    </div>
  </div>
</div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startPush('js'); ?>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });

    var data = <?php echo json_encode($departments, 15, 512) ?>;

  $('#department').on('change', function()
  {
    $("#hall_id").find('option').remove();
    data[this.value].halls.forEach(element => {
      var o = new Option(element.hall_code, element.id);
      /// jquerify the DOM object 'o' so we can use the html method
      $(o).html(element.hall_code);
      $("#hall_id").append(o);
      //$("#courses").append(o);
    });
      //console.log(data[this.value].courses);
  });

    $("#download").click(function() {
      //window.jsPDF = window.jspdf.jsPDF;
      var doc = new jsPDF('p', 'pt', 'a3');  
    var htmlstring = '';  
    var tempVarToCheckPageHeight = 0;  
    var pageHeight = 0;  
    pageHeight = doc.internal.pageSize.height;  
    specialElementHandlers = {  
        // element with id of "bypass" - jQuery style selector  
        '#bypassme': function(element, renderer) {  
            // true = "handled elsewhere, bypass text extraction"  
            return true  
        }  
    };  
    var y = 5;   
    var r_title = "Time Table";
    doc.text(50, y = y + 30, r_title);
    doc.autoTable({  
        html: '#timetable',  
        startY: 70,  
        theme: 'grid',
    })  
    doc.save('reprot.pdf');
    });
  </script>
  <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'Timetable',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Education\School Project\TTMS\resources\views/keeper/report.blade.php ENDPATH**/ ?>