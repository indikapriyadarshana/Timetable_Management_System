

<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row">
    <div class="col-md-10">
      <div class="card">
        <div class="card-header">
          <h5 class="title"><?php echo e(__(" Summary Report")); ?></h5>
        </div>


        <div class="card-body">
          <div id="accordion">
                <table class="table table-bordered text-center"> 
                    <tr>
                        <th>Department</th>
                        <th>Monday</th>
                        <th>Tuesday</th>
                        <th>Wendsday</th>
                        <th>Thursday</th>
                        <th>Friday</th>
                        <th>Saturday</th>
                        <th>Sunday</th>
                        <th>Total</th>

                    </tr>
                    
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($department['name']); ?></td>
                        <td><?php echo e($department['report_data']['monday']); ?>

                        <td><?php echo e($department['report_data']['tuesday']); ?>

                        <td><?php echo e($department['report_data']['wendsday']); ?>

                        <td><?php echo e($department['report_data']['thursday']); ?>

                        <td><?php echo e($department['report_data']['friday']); ?>

                        <td><?php echo e($department['report_data']['saturday']); ?>

                        <td><?php echo e($department['report_data']['sunday']); ?>

                        <td><?php echo e($department['report_data']['total']); ?>


                    </tr>   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <div class="d-flex justify-content-center">
                        <canvas id="myChart" width="400" height="600"></canvas>
                    </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startPush('js'); ?>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      var datas = <?php echo json_encode($departments, 15, 512) ?>;
      var ctx = document.getElementById('myChart').getContext('2d');
      const randomBetween = (min, max) => min + Math.floor(Math.random() * (max - min + 1));

      var lbls = [];
      var bgcolors = [];
      var totals = [];
      for (const [key, value] of Object.entries(datas)) {
        lbls.push(value.name);
        const r = randomBetween(0, 255);
        const g = randomBetween(0, 255);
        const b = randomBetween(0, 255);
        bgcolors.push(`rgba(${r},${g},${b},0.6)`);
        totals.push(value.report_data.total)
      }
        console.log(bgcolors);

      var myChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: lbls,
            datasets: [{
                label: '# of totals',
                data: totals,
                backgroundColor: bgcolors,
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            responsive: false,
        }
    });

      //console.log(t);
      demo.initDashboardPageCharts();

    });
  </script>
  <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'Summary Report',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ttm\resources\views/lecture/summaryreport.blade.php ENDPATH**/ ?>