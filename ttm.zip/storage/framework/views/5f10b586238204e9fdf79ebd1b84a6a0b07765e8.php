<div class="wrapper wrapper-full-page ">
    <?php echo $__env->make('layouts.navbars.navs.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="full-page register-page section-image" style="background-image: url('/assets/img/bg14.jpg')" filter-color="black" data-image="/assets/img/bg16.jpg">
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php /**PATH D:\ttm\resources\views/layouts/page_template/guest.blade.php ENDPATH**/ ?>