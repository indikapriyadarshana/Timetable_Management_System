

<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">


  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h5 class="title"><?php echo e(__(" Edit User Details")); ?></h5>
        </div>
        <div class="card-body">
          <form method="post" action="<?php echo e(route('user.update', $user->id)); ?>" autocomplete="off" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label><?php echo e(__(" Name")); ?></label>
                  <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $user->name)); ?>">
                  <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label for="exampleInputEmail1"><?php echo e(__(" Email address")); ?></label>
                  <input type="email" name="email" class="form-control" placeholder="Email" value="<?php echo e(old('email', $user->email)); ?>">
                  <?php echo $__env->make('alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label for="exampleInputEmail1"><?php echo e(__(" Contact number")); ?></label>
                  <input type="text" name="phone_no" class="form-control" placeholder="Phone" value="<?php echo e(old('phone_no', $user->phone_no)); ?>">
                  <?php echo $__env->make('alerts.feedback', ['field' => 'phone_no'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label><?php echo e(__(" Address")); ?></label>
                  <input type="text" name="address" class="form-control" value="<?php echo e(old('address', $user->address)); ?>">
                  <?php echo $__env->make('alerts.feedback', ['field' => 'address'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              </div>
            </div>
            <!-- <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group <?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                  <label><?php echo e(__(" Password")); ?></label>
                  <input class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('New Password')); ?>" type="password" name="password" required>
                  <?php echo $__env->make('alerts.feedback', ['field' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              </div>
            </div> -->
            <!-- <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group <?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                  <label><?php echo e(__(" Confirm Password")); ?></label>
                  <input class="form-control" placeholder="<?php echo e(__('Confirm New Password')); ?>" type="password" name="password_confirmation" required>
                </div>
              </div>
            </div> -->
            <div class="card-footer ">
              <button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Save')); ?></button>
            </div>
            <hr class="half-rule" />
          </form>
        </div>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
  $(document).ready(function() {
    // Javascript method's body can be found in assets/js/demos.js
    demo.initDashboardPageCharts();

  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'Dashboard',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Education\School Project\TTMS\resources\views/user/edit.blade.php ENDPATH**/ ?>