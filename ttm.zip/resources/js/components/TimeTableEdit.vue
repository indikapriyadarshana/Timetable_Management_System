<template>
  <div style="width: auto; white-space:nowrap;">
    <a href="/dashboard" style="margin-left: 15px; margin-top: 15px"><button class="btn btn-primary">Back to Dashboard</button></a>
    <div style="width: auto; white-space:nowrap; width: 100%; height: 80px; padding: 15px; margin-top: -20px;" class="container-fluid-nav text-center">
    <h2 class="title text-center">
      Time Table - {{ user.course_name }} - Semester {{ user.semester }}
    </h2>
    </div>
    <v-dialog />

    <nav class="navbar navbar-light bg-light">
      <div class="form-inline">
        <div v-if="user.user_role == 'lecture'" class="form-group">
          <label for="Lecture" style="margin-right: 15px">
            Subject:
          </label>
          <select
            class="form-control"
            style="width=250px"
            v-model="subject"
          >
            <option value="" disabled selected>Select your subjects</option>
            <option value="empty">empty</option>
            <option
              :value="index"
              v-bind:key="index"
              v-for="(item, index) in subjects">
              {{ item.name }}
            </option>
          </select>

          <input
            type="button"
            class="form-control btn btn-primary"
            style="margin-left: 15px"
            value="Update"
            @click="updateState"
          />
        </div>

        <div v-if="user.user_role == 'hall_keeper'" class="form-group">
          <label for="Lecture" style="margin-right: 15px"
            >Lecture Hall:
          </label>
          <select
            class="form-control"
            aria-label="Default select example"
            v-model="lecturehall"
          >
            <option value="" disabled selected>
              Select lecture hall
            </option>
            <option value="empty">empty</option>
            <option
              :value="index"
              v-bind:key="index"
              v-for="(item, index) in lecturehalls"
            >
              {{ item.hall_code }}
            </option>
          </select>
          <input
            type="button"
            class="form-control btn btn-primary"
            style="margin-left: 15px"
            value="Update"
            @click="updateState"
          />
        </div>
      </div>
    </nav>
<div class="container" style="margin-left: -10px;">
    <table class="table table-bordered text-center" style="table-layout: auto;">
      <thead>
        <tr class="bg-light-gray">
          <th class="text-uppercase">Days / Time</th>
          <th
            class="text-uppercase"
            v-for="(time, index) in times"
          >
            {{ time }}
          </th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td class="align-middle"><b>Monday</b></td>
          <td v-for="(time, index) in timetable.monday">
            <span
              v-bind:class="changeColor(time)"
              class="
                padding-5px-tb padding-15px-lr
                border-radius-5
                margin-10px-bottom
                text-white
                font-size16
                xs-font-size13
              "
              >{{ time.subject_code }}</span
            >
            <div class="margin-10px-top font-size14">
              {{ time.hall_code }}
            </div>
            <div v-if="( time.subject_code == 'empty' && lecturetable['monday'][index]['allocated'] == 'true' )">
              Allocated
            </div>

            <div v-else>
            <div
              v-if="(user.user_role == 'hall_keeper') ||(time.lecture_id == 0 || time.lecture_id == user.user_id)"
            >
              <input
                type="checkbox"
                class="form-check-input"
                :value="index"
                v-model="checkedMondays"
              />
              <label class="form-check-label" for="exampleCheck1"
                >Select</label
              >
            </div>
            <div v-else>
              <a
                href="#"
                @click="fetchLectureInfo(time.lecture_id)"
                >Details</a
              >
            </div>
            <div v-if="user.user_role == 'hall_keeper' && time.lecture_id != 0">
              <a
                href="#"
                @click="fetchLectureInfo(time.lecture_id)"
                >Details</a
              >
            </div>
            </div>
          </td>
        </tr>
        <tr>
          <td class="align-middle"><b>Tuesday</b></td>
          <td v-for="(time, index) in timetable.tuesday">
            <span
              v-bind:class="changeColor(time)"
              class="
                bg-sky
                padding-5px-tb padding-15px-lr
                border-radius-5
                margin-10px-bottom
                text-white
                font-size16
                xs-font-size13
              "
              >{{ time.subject_code }}</span
            >
            <div class="margin-10px-top font-size14">
              {{ time.hall_code }}
            </div>

            <div v-if="( time.subject_code == 'empty' && lecturetable['tuesday'][index]['allocated'] == 'true' )">
              Allocated
            </div>

            <div v-else>
            <div
              v-if="(user.user_role == 'hall_keeper') ||(time.lecture_id == 0 || time.lecture_id == user.user_id)"
            >
              <input
                type="checkbox"
                class="form-check-input"
                :value="index"
                v-model="checkedTuesdays"
              />
              <label class="form-check-label" for="exampleCheck1"
                >Select</label
              >
            </div>
            <div v-else>
              <a
                href="#"
                @click="fetchLectureInfo(time.lecture_id)"
                >Details</a
              >
            </div>
            <div v-if="user.user_role == 'hall_keeper' && time.lecture_id != 0">
              <a
                href="#"
                @click="fetchLectureInfo(time.lecture_id)"
                >Details</a
              >
            </div>
            </div>
          </td>
        </tr>
        <tr>
          <td class="align-middle"><b>Wendsday</b></td>
          <td v-for="(time, index) in timetable.wendsday">
            <span
              v-bind:class="changeColor(time)"
              class="
                bg-sky
                padding-5px-tb padding-15px-lr
                border-radius-5
                margin-10px-bottom
                text-white
                font-size16
                xs-font-size13
              "
              >{{ time.subject_code }}</span
            >
            <div class="margin-10px-top font-size14">
              {{ time.hall_code }}
            </div>
            <div v-if="( time.subject_code == 'empty' && lecturetable['wendsday'][index]['allocated'] == 'true' )">
              Allocated
            </div>

            <div v-else>
            <div
              v-if="(user.user_role == 'hall_keeper') ||(time.lecture_id == 0 || time.lecture_id == user.user_id)"
            >
              <input
                type="checkbox"
                class="form-check-input"
                :value="index"
                v-model="checkedWendsdays"
              />
              <label class="form-check-label" for="exampleCheck1"
                >Select</label
              >
            </div>
            <div v-else>
              <a
                href="#"
                @click="fetchLectureInfo(time.lecture_id)"
                >Details</a
              >
            </div>
            <div v-if="user.user_role == 'hall_keeper' && time.lecture_id != 0">
              <a
                href="#"
                @click="fetchLectureInfo(time.lecture_id)"
                >Details</a
              >
            </div>
            </div>
          </td>
        </tr>
        <tr>
          <td class="align-middle"><b>Thursday</b></td>
          <td v-for="(time, index) in timetable.thursday">
            <span
              v-bind:class="changeColor(time)"
              class="
                bg-sky
                padding-5px-tb padding-15px-lr
                border-radius-5
                margin-10px-bottom
                text-white
                font-size16
                xs-font-size13
              "
              >{{ time.subject_code }}</span
            >
            <div class="margin-10px-top font-size14">
              {{ time.hall_code }}
            </div>
            <div v-if="( time.subject_code == 'empty' && lecturetable['thursday'][index]['allocated'] == 'true' )">
              Allocated
            </div>

            <div v-else>
            <div
              v-if="(user.user_role == 'hall_keeper') ||(time.lecture_id == 0 || time.lecture_id == user.user_id)"
            >
              <input
                type="checkbox"
                class="form-check-input"
                :value="index"
                v-model="checkedThursdays"
              />
              <label class="form-check-label" for="exampleCheck1"
                >Select</label
              >
            </div>
            <div v-else>
              <a
                href="#"
                @click="fetchLectureInfo(time.lecture_id)"
                >Details</a
              >
            </div>
            <div v-if="user.user_role == 'hall_keeper' && time.lecture_id != 0">
              <a
                href="#"
                @click="fetchLectureInfo(time.lecture_id)"
                >Details</a
              >
            </div>
            </div>
          </td>
        </tr>
        <tr>
          <td class="align-middle"><b>Friday</b></td>
          <td v-for="(time, index) in timetable.friday">
            <span
              v-bind:class="changeColor(time)"
              class="
                bg-sky
                padding-5px-tb padding-15px-lr
                border-radius-5
                margin-10px-bottom
                text-white
                font-size16
                xs-font-size13
              "
              >{{ time.subject_code }}</span
            >
            <div class="margin-10px-top font-size14">
              {{ time.hall_code }}
            </div>
            <div v-if="( time.subject_code == 'empty' && lecturetable['friday'][index]['allocated'] == 'true' )">
              Allocated
            </div>

            <div v-else>
            <div
              v-if="(user.user_role == 'hall_keeper') ||(time.lecture_id == 0 || time.lecture_id == user.user_id)"
            >
              <input
                type="checkbox"
                class="form-check-input"
                :value="index"
                v-model="checkedFridays"
              />
              <label class="form-check-label" for="exampleCheck1"
                >Select</label
              >
            </div>
            <div v-else>
              <a
                href="#"
                @click="fetchLectureInfo(time.lecture_id)"
                >Details</a
              >
            </div>
            <div v-if="user.user_role == 'hall_keeper' && time.lecture_id != 0">
              <a
                href="#"
                @click="fetchLectureInfo(time.lecture_id)"
                >Details</a
              >
            </div>
            </div>
          </td>
        </tr>
        <tr>
          <td class="align-middle"><b>Saturday</b></td>
          <td v-for="(time, index) in timetable.saturday">
            <span
              v-bind:class="changeColor(time)"
              class="
                bg-sky
                padding-5px-tb padding-15px-lr
                border-radius-5
                margin-10px-bottom
                text-white
                font-size16
                xs-font-size13
              "
              >{{ time.subject_code }}</span
            >
            <div class="margin-10px-top font-size14">
              {{ time.hall_code }}
            </div>
            <div v-if="( time.subject_code == 'empty' && lecturetable['saturday'][index]['allocated'] == 'true' )">
              Allocated
            </div>

            <div v-else>
            <div
              v-if="(user.user_role == 'hall_keeper') ||(time.lecture_id == 0 || time.lecture_id == user.user_id)"
            >
              <input
                type="checkbox"
                class="form-check-input"
                :value="index"
                v-model="checkedSaturdays"
              />
              <label class="form-check-label" for="exampleCheck1"
                >Select</label
              >
            </div>
            <div v-else>
              <a
                href="#"
                @click="fetchLectureInfo(time.lecture_id)"
                >Details</a
              >
            </div>
            <div v-if="user.user_role == 'hall_keeper' && time.lecture_id != 0">
              <a
                href="#"
                @click="fetchLectureInfo(time.lecture_id)"
                >Details</a
              >
            </div>
            </div>
          </td>
        </tr>
        <tr>
          <td class="align-middle"><b>Sunday</b></td>
          <td v-for="(time, index) in timetable.sunday">
            <span
              v-bind:class="changeColor(time)"
              class="
                bg-sky
                padding-5px-tb padding-15px-lr
                border-radius-5
                margin-10px-bottom
                text-white
                font-size16
                xs-font-size13
              "
              >{{ time.subject_code }}</span
            >
            <div class="margin-10px-top font-size14">
              {{ time.hall_code }}
            </div>
            <div v-if="( time.subject_code == 'empty' && lecturetable['sunday'][index]['allocated'] == 'true' )">
              Allocated
            </div>

            <div v-else>
            <div
              v-if="(user.user_role == 'hall_keeper') ||(time.lecture_id == 0 || time.lecture_id == user.user_id)"
            >
              <input
                type="checkbox"
                class="form-check-input"
                :value="index"
                v-model="checkedSundays"
              />
              <label class="form-check-label" for="exampleCheck1"
                >Select</label
              >
            </div>
            <div v-else>
              <a
                href="#"
                @click="fetchLectureInfo(time.lecture_id)"
                >Details</a
              >
            </div>
            <div v-if="user.user_role == 'hall_keeper' && time.lecture_id != 0">
              <a
                href="#"
                @click="fetchLectureInfo(time.lecture_id)"
                >Details</a
              >
            </div>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
   </div>
  </div>
</template>




<script>
export default {
  props: {
    table: {},
    subjects: [],
    lecturehalls: [],
    user: {},
    lecturetable: {},
  },

  data() {
    return {
      times: [],
      timetable: this.table,
      checkedMondays: [],
      checkedTuesdays: [],
      checkedWendsdays: [],
      checkedThursdays: [],
      checkedFridays: [],
      checkedSaturdays: [],
      checkedSundays: [],

      subject: "",
      lecturehall: "",
      lectureinfo: [],
    };
  },
  mounted() {
    console.log("Component mounted.");
    this.populateTimes();
    //console.log(this.tuesday[0].time)
    this.listen();
    //this.fetchDepartments()
    console.log(this.lecturetable['monday']);
    
  },

  methods: {
    populateTimes() {
      for (let index = 6; index < 24; index++) {
        this.times.push(index);
      }
    },

    listen() {
      Echo.channel("timetable." + this.user.table_id).listen(
        "TimeTableEvent",
        (table) => {
          //this.timetable = table;
          //let ty = JSON.parse(table);
          console.log(table.table_info);
          this.timetable = table.table_info;
          let instance = Vue.$toast.open({
            message: "Time Table Updated",
            position: "bottom",
          });
        }
      );
    },

    onbtnclick() {
      this.checkedMondays.forEach((element) => {
        this.timetable.monday[element].subject_code = "dfsdfsd";
      });
    },

    updateTable(element) {
      if (
        this.user.user_role == "lecture" &&
        (element.lecture_id == 0 || this.user.user_id == element.lecture_id)
      ) {
        if (this.subject == 'empty'){
          element.subject_code = 'empty';
          element.subject_id = '0';
          element.lecture_id = '0';
        } else {
          element.subject_code = this.subjects[this.subject].name;
          element.subject_id = this.subjects[this.subject].id;
          element.lecture_id = this.user.user_id;
        }
        
      } else if (this.user.user_role == "hall_keeper") {
        if (this.lecturehall == 'empty'){
          element.hall_code = 'empty';
          element.hall_id = '0';
        } else {
        element.hall_code = this.lecturehalls[this.lecturehall].hall_code;
        element.hall_id = this.lecturehalls[this.lecturehall].id;
        }
      }
    },

    changeColor(s) {
      if (s.subject_code == "empty" && s.hall_code == "empty") {
        return "bg-lightred";
      } else {
        return "bg-sky";
      }
    },

    showLectureInfoModal(data) {
      this.$modal.show("dialog", {
        title: "Lecture Info",
        text:
          "Name: " +
          data.name +
          "<br>Email: " +
          data.email +
          "<br>Phone No: " +
          data.phone_no,
        buttons: [
          {
            title: "Close",
            handler: () => {
              this.$modal.hide("dialog");
            },
          },
        ],
      });
    },

    showNotFoundModal() {
      alert("not found");
    },

    async fetchLectureInfo(id) {
      const res = await fetch("/lecture/show/" + id);
      const data = await res.json();
      if ("error" in data) {
        this.showNotFoundModal();
      } else {
        this.showLectureInfoModal(data);
      }
    },

    updateState() {
      this.checkedMondays.forEach((element) => {
        this.updateTable(this.timetable.monday[element]);
      });

      this.checkedTuesdays.forEach((element) => {
        this.updateTable(this.timetable.tuesday[element]);
      });

      this.checkedWendsdays.forEach((element) => {
        this.updateTable(this.timetable.wendsday[element]);
      });

      this.checkedThursdays.forEach((element) => {
        this.updateTable(this.timetable.thursday[element]);
      });

      this.checkedFridays.forEach((element) => {
        this.updateTable(this.timetable.friday[element]);
      });

      this.checkedSaturdays.forEach((element) => {
        this.updateTable(this.timetable.saturday[element]);
      });

      this.checkedSundays.forEach((element) => {
        this.updateTable(this.timetable.sunday[element]);
      });

      axios
        .put("/timetable/" + this.user.table_id, { table_info: this.timetable })
        .then(function (res) {
          console.log(res.data);
        });
      let instance = Vue.$toast.open({
        message: "Time Table Updated",
        position: "bottom",
      });

      this.checkedMondays = [];
      this.checkedTuesdays = [];
      this.checkedWendsdays = [];
      this.checkedThursdays = [];
      this.checkedFridays = [];
      this.checkedSaturdays = [];
      this.checkedSundays = [];
    },
  },
};
</script>

<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>