<template>
    <div style="width: auto; white-space:nowrap;">
        <a href="/dashboard" style="margin-left: 15px; margin-top: 15px"><button class="btn btn-primary">Back to Dashboard</button></a>
    <div style="width: auto; white-space:nowrap; width: 100%; height: 80px; padding: 15px; margin-top: -20px;" class="container-fluid-nav text-center">
    <h2 class="title text-center">
      Time Table - {{ user.course_name }} - Semester {{ user.semester }}
    </h2>
    </div>
    <v-dialog />

    <v-dialog />
    <div class="container-fluid">
        <table class="table table-bordered text-center">
            <thead>
                <tr class="bg-light-gray">
                    <th class="text-uppercase">Days / Time</th>
                    <th class="text-uppercase" v-for="(time, index) in times">{{time}}</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="align-middle"><b>Monday</b></td>
                    <td v-for="(time, index) in timetable.monday">
                        <span v-bind:class="changeColor(time)" class="padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">{{time.subject_code}}</span>
                        <div class="margin-10px-top font-size14">{{time.hall_code}}</div>
                        <div v-if="time.subject_code != 'empty'">
                            <a href='#' @click="fetchLectureInfo(time.lecture_id)">Details</a>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="align-middle"><b>Tuesday</b></td>
                    <td v-for="(time, index) in timetable.tuesday">
                        <span v-bind:class="changeColor(time)" class="padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">{{time.subject_code}}</span>
                        <div class="margin-10px-top font-size14">{{time.hall_code}}</div>
                        <div v-if="time.subject_code != 'empty'">
                            <a href='#' @click="fetchLectureInfo(time.lecture_id)">Details</a>
                        </div>
                    </td>
                    
                </tr>
                <tr>
                    <td class="align-middle"><b>Wendsday</b></td>
                    <td v-for="(time, index) in timetable.wendsday">
                        <span v-bind:class="changeColor(time)" class="padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">{{time.subject_code}}</span>
                        <div class="margin-10px-top font-size14">{{time.hall_code}}</div>
                        <div v-if="time.subject_code != 'empty'">
                            <a href='#' @click="fetchLectureInfo(time.lecture_id)">Details</a>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="align-middle"><b>Thursday</b></td>
                    <td v-for="(time, index) in timetable.thursday">
                        <span v-bind:class="changeColor(time)" class="padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">{{time.subject_code}}</span>
                        <div class="margin-10px-top font-size14">{{time.hall_code}}</div>
                        <div v-if="time.subject_code != 'empty'">
                            <a href='#' @click="fetchLectureInfo(time.lecture_id)">Details</a>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="align-middle"><b>Friday</b></td>
                    <td v-for="(time, index) in timetable.friday">
                        <span v-bind:class="changeColor(time)" class="padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">{{time.subject_code}}</span>
                        <div class="margin-10px-top font-size14">{{time.hall_code}}</div>
                        <div v-if="time.subject_code != 'empty'">
                            <a href='#' @click="fetchLectureInfo(time.lecture_id)">Details</a>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="align-middle"><b>Saturday</b></td>
                    <td v-for="(time, index) in timetable.saturday">
                        <span v-bind:class="changeColor(time)" class="padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">{{time.subject_code}}</span>
                        <div class="margin-10px-top font-size14">{{time.hall_code}}</div>
                        <div v-if="time.subject_code != 'empty'">
                            <a href='#' @click="fetchLectureInfo(time.lecture_id)">Details</a>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="align-middle"><b>Sunday</b></td>
                    <td v-for="(time, index) in timetable.sunday">
                        <span v-bind:class="changeColor(time)" class="padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">{{time.subject_code}}</span>
                        <div class="margin-10px-top font-size14">{{time.hall_code}}</div>
                        <div v-if="time.subject_code != 'empty'">
                            <a href='#' @click="fetchLectureInfo(time.lecture_id)">Details</a>
                        </div>
                    </td>
                </tr>

            </tbody>
        </table>
    </div>
</div>
</template>

<script>
    export default {

        props: {
            table: {},
            user: {},
        },

        data() {
            return { 
                times: [],
                timetable: this.table,
            }
        },
        mounted() {
            console.log('Component mounted.')
            this.populateTimes()
            //console.log(this.tuesday[0].time)
            this.listen()
        },

        methods: {
            populateTimes() {
                for (let index = 6; index < 24; index++) {
                    this.times.push(index);
                }
            },

            showLectureInfoModal(data) {
                this.$modal.show('dialog', {
                    title: 'Lecture Info',
                    text: 'Name: ' + data.name + '<br>Email: ' + data.email + '<br>Phone No: ' + data.phone_no,
                    buttons: [
                        {
                        title: 'Close',
                        handler: () => {
                            this.$modal.hide('dialog')
                        }
                        },
                    ]
                });
            },

            showNotFoundModal() {
                this.$modal.show('dialog', {
                    title: 'Lecture Info',
                    text: 'Lecture not found',
                    buttons: [
                        {
                        title: 'Close',
                        handler: () => {
                            this.$modal.hide('dialog')
                        }
                        },
                    ]
                });
            },

            async fetchLectureInfo(id) {
                
                const res = await fetch('/lecture/show/' + id);
                const data = await res.json();
                if ('error' in data) {
                    this.showNotFoundModal();
                } else {
                    this.showLectureInfoModal(data);
                }
                
            },

            changeColor(s) {
                if (s.subject_code == "empty" && s.hall_code == "empty") {
                    return 'bg-lightred';
                } else {
                    return 'bg-sky';
                }

            },

            listen() {
            Echo.channel("timetable." + this.user.table_id).listen("TimeTableEvent", table => {
                console.log(table.table_info);
                this.timetable = table.table_info;
                let instance = Vue.$toast.open({'message': 'Time Table Updated', 'position' : 'bottom'});
            });
        }
        }
    }
</script>

<style>
    /* The heart of the matter */
        
    .horizontal-scrollable > .row {
        overflow-x: auto;
        white-space: nowrap;
    }
        
    .horizontal-scrollable > .row > .col-xs-4 {
        display: inline-block;
        float: none;
    }
    /* Decorations */
        
    .col-xs-4 {
        color: white;
        font-size: 24px;
        padding-bottom: 20px;
        padding-top: 18px;
    }
        
    .col-xs-4:nth-child(2n+1) {
        background: green;
    }
        
    .col-xs-4:nth-child(2n+2) {
        background: black;
    }
</style>
