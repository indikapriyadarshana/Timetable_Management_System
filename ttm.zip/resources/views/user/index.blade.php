@extends('layouts.app', [
'namePage' => 'Users',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
])

@section('content')
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">


  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h5 class="title">{{__(" Add New User")}}</h5>
        </div>
        <div class="card-body">
          <form method="post" action="{{ route('user.store', auth()->user()->id) }}" autocomplete="off" enctype="multipart/form-data">
            @csrf
            @include('alerts.success')
            <div class="row">
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label>{{__(" Name")}}</label>
                  <input type="text" name="name" class="form-control" value="" placeholder="Name">
                  @include('alerts.feedback', ['field' => 'name'])
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label for="exampleInputEmail1">{{__(" Email address")}}</label>
                  <input type="email" name="email" class="form-control" placeholder="Email" value="">
                  @include('alerts.feedback', ['field' => 'email'])
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label for="exampleInputEmail1">{{__(" Contact number")}}</label>
                  <input type="text" name="phone_no" class="form-control" placeholder="Phone" value="">
                  @include('alerts.feedback', ['field' => 'phone_no'])
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label>{{__(" Address")}}</label>
                  <input type="text" name="address" class="form-control" value="" placeholder="Address">
                  @include('alerts.feedback', ['field' => 'address'])
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label>{{__(" User Role")}}</label>
                  <select class="form-control" id="exampleFormControlSelect1" name="role_id" value="">
                  @foreach ($roles as $role) 
                  <option value="{{$role->id}}">{{$role->name}}</option>
                  @endforeach
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group">
                  <label>{{__(" Department")}}</label>
                  <select class="form-control" id="department_id" name="department_id" value="">
                  @foreach ($departments as $department) 
                  <option value="{{$department->id}}">{{$department->name}}</option>
                  @endforeach
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group {{ $errors->has('password') ? ' has-danger' : '' }}">
                  <label>{{__(" Password")}}</label>
                  <input class="form-control {{ $errors->has('password') ? ' is-invalid' : '' }}" placeholder="{{ __('New Password') }}" type="password" name="password" required>
                  @include('alerts.feedback', ['field' => 'password'])
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-7 pr-1">
                <div class="form-group {{ $errors->has('password') ? ' has-danger' : '' }}">
                  <label>{{__(" Confirm Password")}}</label>
                  <input class="form-control" placeholder="{{ __('Confirm New Password') }}" type="password" name="password_confirmation" required>
                </div>
              </div>
            </div>
            <div class="card-footer ">
              <button type="submit" class="btn btn-primary btn-round">{{__('Save')}}</button>
            </div>
            <hr class="half-rule" />
          </form>
        </div>
      </div>
    </div>
  </div>

  @foreach($data as $role)
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h5 class="title">{{$role['slug']}}</h5>
        </div>
        <div class="card-body">
          @foreach ($role['users'] as $user)
          <div class="d-flex justify-content-between">
            <h5>{{$user->name}}</h5>
            <a class="btn btn-primary btn-round" href="{{ route('user.edit',$user->id) }}">Edit</a>
          </div>
          @endforeach
        </div>
      </div>
    </div>
  </div>
@endforeach
  

  

</div>
@endsection
@push('js')
<script>
  $(document).ready(function() {
    // Javascript method's body can be found in assets/js/demos.js
    demo.initDashboardPageCharts();

  });
</script>
@endpush