@extends('layouts.app', [
'namePage' => 'Dashboard',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
])

@section('content')
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">


  <div class="row justify-content-md-center">
    <div class="col-md-6">
      <div class="card card-user">
        <div class="image">
          <img src="{{asset('assets')}}/img/bg5.jpg" alt="...">
        </div>
        <div class="card-body">
          <div class="author">
            <a href="#">
              <img class="avatar border-gray" src="{{asset('assets')}}/img/default-avatar.png" alt="...">
              <h5 class="title">{{$data->name}}</h5>
            </a>
            <h5>
              {{ $data->email }} <br>
              {{$data->phone_no}} <br>
              {{$data->address}}
            </h5>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
@endsection
@push('js')
<script>
  $(document).ready(function() {
    // Javascript method's body can be found in assets/js/demos.js
    demo.initDashboardPageCharts();

  });
</script>
@endpush