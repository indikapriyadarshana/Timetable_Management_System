@extends('layouts.app', [
'namePage' => 'Summary Report',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
])

@section('content')
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row">
    <div class="col-md-10">
      <div class="card">
        <div class="card-header">
          <h5 class="title">{{__(" Summary Report")}}</h5>
        </div>


        <div class="card-body">
          <div id="accordion">
                <table class="table table-bordered text-center"> 
                    <tr>
                        <th>Department</th>
                        <th>Monday</th>
                        <th>Tuesday</th>
                        <th>Wendsday</th>
                        <th>Thursday</th>
                        <th>Friday</th>
                        <th>Saturday</th>
                        <th>Sunday</th>
                        <th>Total</th>

                    </tr>
                    
                    @foreach ($departments as $department)
                    <tr>
                        <td>{{$department['name']}}</td>
                        <td>{{$department['report_data']['monday']}}
                        <td>{{$department['report_data']['tuesday']}}
                        <td>{{$department['report_data']['wendsday']}}
                        <td>{{$department['report_data']['thursday']}}
                        <td>{{$department['report_data']['friday']}}
                        <td>{{$department['report_data']['saturday']}}
                        <td>{{$department['report_data']['sunday']}}
                        <td>{{$department['report_data']['total']}}

                    </tr>   
                    @endforeach
                    </table>
                    <div class="d-flex justify-content-center">
                        <canvas id="myChart" width="400" height="600"></canvas>
                    </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
  @endsection
  @push('js')
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      var datas = @json($departments);
      var ctx = document.getElementById('myChart').getContext('2d');
      const randomBetween = (min, max) => min + Math.floor(Math.random() * (max - min + 1));

      var lbls = [];
      var bgcolors = [];
      var totals = [];
      for (const [key, value] of Object.entries(datas)) {
        lbls.push(value.name);
        const r = randomBetween(0, 255);
        const g = randomBetween(0, 255);
        const b = randomBetween(0, 255);
        bgcolors.push(`rgba(${r},${g},${b},0.6)`);
        totals.push(value.report_data.total)
      }
        console.log(bgcolors);

      var myChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: lbls,
            datasets: [{
                label: '# of totals',
                data: totals,
                backgroundColor: bgcolors,
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            responsive: false,
        }
    });

      //console.log(t);
      demo.initDashboardPageCharts();

    });
  </script>
  @endpush