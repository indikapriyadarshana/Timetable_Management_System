@extends('layouts.app', [
'namePage' => 'Timetable',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
])

@section('content')
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row">
    <div class="col-md-13">
      <div class="card">
        <div class="card-header">
          <h5 class="title">{{__(" Student Timetable")}}</h5>
          <button id="download" class="btn btn-primary">Download</button>
        </div>
            <div class="container">
                <table id="timetable" class="table table-bordered text-center"> 
                    <tr>
                      <th>Day/Time</th>
                      <th>Monday</th>
                      <th>Tuesday</th>
                      <th>Wenday</th>
                      <th>Thursday</th>
                      <th>Friday</th>
                      <th>Saturday</th>
                      <th>Sunday</th>
                    </tr>
                     
                    @foreach ($data as $key => $row)
                      <tr> 
                          <td><b>{{$key + 6}}. 00</b></td>
                          @foreach ($row as $key2 => $row2)
                          <td> 
                          @if ( isset($row2['lecture_name']))
                          <span  class="badge badge-danger badge-pill">{{$row2['lecture_name']}}</span><br>
                          @endif
                            @if ( isset($row2['course_name']))
                          <span  class="badge badge-info badge-pill">{{$row2['course_name']}}</span><br>
                          @endif
                          <p>{{$row2['subject_code']}}</p>
                        </td>
                          @endforeach
                      </tr>
                      @endforeach
                    
                </table>
            </div>
      </div>
    </div>
  </div>
</div>
  @endsection
  @push('js')
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });

  

    $("#download").click(function() {
      //window.jsPDF = window.jspdf.jsPDF;
      var doc = new jsPDF('p', 'pt', 'a3');  
      var student_name = "{{$student_name}}";
    var htmlstring = '';  
    var tempVarToCheckPageHeight = 0;  
    var pageHeight = 0;  
    pageHeight = doc.internal.pageSize.height;  
    specialElementHandlers = {  
        // element with id of "bypass" - jQuery style selector  
        '#bypassme': function(element, renderer) {  
            // true = "handled elsewhere, bypass text extraction"  
            return true  
        }  
    };  
    var y = 5;   
    doc.text(50, y = y + 30, "Time Table - " + student_name);
    doc.autoTable({  
        html: '#timetable',  
        startY: 70,  
        theme: 'grid',
    })  
    doc.save('reprot.pdf');
    });

    <input type="hidden" name="course_id" value="{{$course->id}}">
          <div class="card-footer ">
            <button type="submit" class="btn btn-primary btn-round">{{__('Add Subject')}}</button>
          </div>

  </script>
  @endpush