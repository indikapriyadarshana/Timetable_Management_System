@extends('layouts.timetable')

@section('content')
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div id="app">
  <timetable-show :table="{{ $table }}" :user="{{ $user }}"></timetable-show>
</div>

@endsection
