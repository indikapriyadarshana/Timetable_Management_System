@extends('layouts.app', [
'namePage' => 'Time Tables',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
])

@section('content')
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h5 class="title">{{$tables->first()->course->name}}</h5>
        </div>
        <div class="card-body">
          <div id="accordion">
            
            <table class="table table-bordered text-center" style="table-layout: auto;">   
                <tr>
                  <th>Semester</th>
                  <th>View</th>
                  <th>Report</th>
                </tr>
                @foreach ($tables as $table)
                <tr>
                  <td>Semester - {{$table->semester}}</td>
                  <td><a href="{{route('timetable.show', $table->id)}}">View</a></td>
                  <td><a href="{{route('student.report', $table->id)}}">Report</a></td>
                </tr>
                @endforeach
            </table>
            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
  @endsection
  @push('js')
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });
  </script>
  @endpush