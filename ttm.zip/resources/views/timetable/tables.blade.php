@extends('layouts.app', [
'namePage' => 'TIMETABLE',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
])

@section('content')
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h5 class="title">{{__(" Courses")}}</h5>
        </div>


        <div class="card-body">
          <div id="accordion">
            @foreach ($departments as $department)
            <div class="card">
              <div class="card-header" id="headingOne">
                <h5 class="mb-0">
                  <button class="btn btn-link" data-toggle="collapse" data-target="#collapse{{$department->id}}" aria-expanded="true" aria-controls="collapse{{$department->id}}">
                    {{$department->name}}
                  </button>
                </h5>
              </div>

              <div id="collapse{{$department->id}}" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                <div class="card-body">
                  
                  
                  <table class="table table-bordered text-center" style="table-layout: auto;">   
                      <tr>
                        <th>Course</th>
                        <th>Semester</th>
                        <th>View</th>
                        @if (auth()->user()->role->name === "lecture" || auth()->user()->role->name === "hall_keeper")
                        <th>Edit</th>
                        @endif
                        </tr>
                        
                        @foreach ($department->courses as $course)
                        @foreach ($course->timetable as $table)
                        <tr>
                            <td>{{$course->name}}</td>
                            <td>{{$table->semester}}</td>
                            <td><a href="{{route('timetable.show', $table->id)}}" target="_blank">View</a></td>
                            @if (auth()->user()->role->name === "lecture" || auth()->user()->role->name === "hall_keeper")
                            <td><a href="{{route('timetable.edit', $table->id)}}">Edit</a></td>
                            @endif
                        </tr>
                        @endforeach
                        @endforeach
                        
                    </table>
                </div>
              </div>
            </div>
            @endforeach
          </div>
        </div>
      </div>
    </div>
  </div>
  @endsection
  @push('js')
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });
  </script>
  @endpush