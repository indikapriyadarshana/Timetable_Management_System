@extends('layouts.timetable')

@section('content')
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div id="app">
  <timetable-edit :table="{{ $table }}" :subjects="{{ $subjects }}" :lecturehalls="{{ $lecturehalls }} " :user="{{ $user }}" :lecturetable="{{ $lecturetable }}"></timetable-edit>
</div>

@endsection