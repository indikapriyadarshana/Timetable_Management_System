@extends('layouts.app', [
'namePage' => 'Timetable',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
])

@section('content')
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row">
    <div class="col-md-13">
      <div class="card">
        <div class="card-header">
          <h5 class="title">{{__(" Keeper Timetable")}}</h5>
          <form method="post" action="{{ route('hallkeeper.generate') }}">
          @csrf
              <div class="form-row">

                <div class="form-group">
                  <label for="exampleInputEmail1" style="margin-top: 10px; margin-left:15px">Department: </label>
                </div>

                <div class="form-group"> 
                  <select class="form-control" id="department" name="department" style="margin-left:15px;">
                      <option value="" selected>Select Department</option>   
                      @foreach ($departments as $department)
                        <option value="{{$department['id']}}">{{$department['name']}}</option>
                      @endforeach
                  </select>
                </div>


                <div class="form-group" style="margin-left: 15px">
                  <label for="exampleInputEmail1" style="margin-top: 10px; margin-left:15px">Hall Code</label>
                </div>

                <div class="form-group"> 
                  <select class="form-control" id="hall_id" name="hall_id" style="margin-left:15px;">
                  <option value="" disabled selected>Select lecture hall</option>
                </select>
                </div>

                <div class="form-group" style="margin-top: 10px; margin-left:20px">
                  <label for="exampleInputEmail1"> Type</label>
                </div>

                <div class="form-group"> 
                  <select class="form-control" id="keeper_table" name="keeper_table" style="margin-left:15px;">
                        <option value="keeper_table">Keeper Table</option>
                        <option value="subject_report">Subject Report</option>
                  </select>
                </div>
                
                <div class="form-group" style="margin-left: 15px">
                  <input type="submit" class="btn btn-primary" value="Generate" style="margin-top: -1px; margin-left: 15px">
                </div>

                <div class="form-group">
                  <input type="button" id="download" class="btn btn-primary" style="margin-top: -1px; margin-left: 15px" value="Download"></input>
                </div>
              </div>
          </form>
          
        </div>
            <div class="container">
              @if(isset($tbl))
                <table id="timetable" class="table table-bordered text-center"> 
                    <tr>
                      <th>Day/Time</th>
                      <th>Monday</th>
                      <th>Tuesday</th>
                      <th>Wenday</th>
                      <th>Thursday</th>
                      <th>Friday</th>
                      <th>Saturday</th>
                      <th>Sunday</th>
                    </tr>
                     
                    @foreach ($tbl as $key => $row)
                      <tr> 
                          <td><b>{{$key + 6}}. 00</b></td>
                          @foreach ($row as $key2 => $row2)
                          <td> 
                          @if ( isset($row2['lecture_name']))
                          <span  class="badge badge-danger badge-pill">{{$row2['lecture_name']}}</span><br>
                          @endif
                            @if ( isset($row2['course_name']))
                          <span  class="badge badge-info badge-pill">{{$row2['course_name']}}</span><br>
                          @endif
                          <p>{{$row2['subject_code']}}</p>
                        </td>
                          @endforeach
                      </tr>
                      @endforeach
                    
                </table>
              @endif
              @if(isset($subject_report))
              <table id="timetable" class="table table-bordered text-center"> 
                    <tr>
                      <th>Hall Code</th>
                      <th>Course Name</th>
                      <th>Subject Count</th>
                    </tr>
                      
                    @foreach($subject_report as $row) 
                    <tr>
                      <td>{{$row['hall_code']}}</td>
                      <td>{{$row['course_name']}}</td>
                      <td>{{$row['count']}}</td>
                    </tr>
                    @endforeach
              </table>
              @endif
            </div>
      </div>
    </div>
  </div>
</div>
  @endsection
  @push('js')
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });

    var data = @json($departments);
    @if (isset($report_title))
    var report_title = "{{$report_title}}";
    @endif

  $('#department').on('change', function()
  {
    $("#hall_id").find('option').remove();
    data[this.value].halls.forEach(element => {
      var o = new Option(element.hall_code, element.id);
      /// jquerify the DOM object 'o' so we can use the html method
      $(o).html(element.hall_code);
      $("#hall_id").append(o);
      //$("#courses").append(o);
    });
      //console.log(data[this.value].courses);
  });

    $("#download").click(function() {
      //window.jsPDF = window.jspdf.jsPDF;
      var doc = new jsPDF('p', 'pt', 'a3');  
    var htmlstring = '';  
    var tempVarToCheckPageHeight = 0;  
    var pageHeight = 0;  
    pageHeight = doc.internal.pageSize.height;  
    specialElementHandlers = {  
        // element with id of "bypass" - jQuery style selector  
        '#bypassme': function(element, renderer) {  
            // true = "handled elsewhere, bypass text extraction"  
            return true  
        }  
    };  
    var y = 5;   
    var r_title = report_title;
    doc.text(50, y = y + 30, r_title);
    doc.autoTable({  
        html: '#timetable',  
        startY: 70,  
        theme: 'grid',
    })  
    doc.save('reprot.pdf');
    });
  </script>
  @endpush