@extends('layouts.app', [
'namePage' => 'Summary Report',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
])

@section('content')
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h5 class="title">{{__(" Report")}}</h5>
        </div>
            <div class="card-body">
              <div id="accordion">

                <div class="card">               
                  <div class="card-header" id="headingOne">
                    <h5 class="mb-0">
                      <button class="btn btn-link" data-toggle="collapse" data-target="#collapse_userreport" aria-expanded="true" aria-controls="collapse_userreport">
                        Users Report
                      </button>
                    </h5>
                  </div>

                  <div id="collapse_userreport" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                  <div class="card-body">
                    <h6>Report</h6>
                    <div class="container" style="margin-left: -10px;">
                      <table class="table table-bordered text-center" style="table-layout: auto;">   
                      <tr>
                        <th>User Type</th>
                        <th>Count</th>
                        </tr>
                        @foreach( $data['userreport'] as $row) 
                        <tr>
                          <td>{{$row->slug}}</td>
                          <td>{{$row->count}}</td>
                        </tr>
                        @endforeach
                      </table>
                  </div>
                    </div>
                  </div>

                </div>

                <div class="card">               
                  <div class="card-header" id="headingOne">
                    <h5 class="mb-0">
                      <button class="btn btn-link" data-toggle="collapse" data-target="#collapse_lecturereport" aria-expanded="true" aria-controls="collapse_lecturereport">
                        Lectures Report
                      </button>
                    </h5>
                  </div>

                  <div id="collapse_lecturereport" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                  <div class="card-body">
                    <h6>Report</h6>
                    <div class="container" style="margin-left: -10px;">
                      <table class="table table-bordered text-center" style="table-layout: auto;">   
                      <tr>
                        <th>Lecture Name</th>
                        <th>Total Working Hours</th>
                        </tr>
                        @foreach( $data['lecturereport'] as $key => $value) 
                        <tr>
                          <td>{{$value['name']}}</td>
                          <td>{{$value['count']}}</td>
                        </tr>
                        @endforeach
                      </table>
                  </div>
                    </div>
                  </div>

                </div>
          </div>
      </div>
    </div>
  </div>
</div>
  @endsection
  @push('js')
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });
  </script>
  @endpush