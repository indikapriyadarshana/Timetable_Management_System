<div class="wrapper wrapper-full-page ">
    @include('layouts.navbars.navs.guest')
    <div class="full-page register-page section-image" style="background-image: url('/assets/img/bg14.jpg')" filter-color="black" data-image="/assets/img/bg16.jpg">
        @yield('content')
        @include('layouts.footer')
    </div>
</div>
