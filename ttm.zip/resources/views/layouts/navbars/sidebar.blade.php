<div class="sidebar" data-color="orange">
  <!--
    Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
-->
  <div class="logo">
    <a href="" class="simple-text logo-mini">
    <i class="now-ui-icons users_circle-08"></i>
    </a>
    <a href="" class="simple-text logo-normal">
      {{ auth()->user()->role->slug }}
    </a>
  </div>
  <div class="sidebar-wrapper" id="sidebar-wrapper">
    <ul class="nav">
      <li class="">
        <a href="{{route('dashboard')}}">
          <i class="now-ui-icons design_app"></i>
          <p>{{ __('Dashboard') }}</p>
        </a>
      </li>
      <li>

      @if (auth()->user()->role->name === "admin")
      <li class="">
        <a href="{{ route('department.index') }}">
          <i class="now-ui-icons education_hat"></i>
          <p> {{ __("Departments") }} </p>
        </a>
      </li>
      @endif
      
      @if (auth()->user()->role->name !== "admin")
      <li class="">
        <a href="{{ route('timetable.index') }}">
          <i class="now-ui-icons design_bullet-list-67"></i>
          <p>{{ __('Time Tables') }}</p>
        </a>
      </li>
      @endif

      @if (auth()->user()->role->name === "admin")
      <li class="">
        <a href="{{ route('courses.index') }}">
          <i class="now-ui-icons files_single-copy-04"></i>
          <p> {{ __("Courses") }} </p>
        </a>
      </li>
      @endif

      @if (auth()->user()->role->name === "admin")
      <li class="">
        <a href="{{ route('lecturehall.index') }}">
          <i class="now-ui-icons business_bank"></i>
          <p> {{ __("Lecture Halls") }} </p>
        </a>
      </li>
      @endif

      @if (auth()->user()->role->name === "admin")
      <li class="">
        <a href="{{ route('user.index') }}">
          <i class="now-ui-icons users_single-02"></i>
          <p> {{ __("Users") }} </p>
        </a>
      </li>
      @endif

      @if (auth()->user()->role->name === "lecture")
      <li class="">
        <a href="{{ route('lecture.lecturetimetable') }}">
          <i class="now-ui-icons business_chart-bar-32"></i>
          <p> {{ __("Lecture Timetable") }} </p>
        </a>
      </li>
      @endif

      @if (auth()->user()->role->name === "hall_keeper")
      <li class="">
        <a href="{{ route('hallkeeper.report') }}">
          <i class="now-ui-icons business_chart-bar-32"></i>
          <p> {{ __("Report") }} </p>
        </a>
      </li>
      @endif

      @if (auth()->user()->role->name === "lecture")
      <li class="">
        <a href="{{ route('lecture.summaryreport') }}">
          <i class="now-ui-icons business_chart-pie-36"></i>
          <p> {{ __("Summary Report") }} </p>
        </a>
      </li>
      @endif

      @if (auth()->user()->role->name === "admin")
      <li class="">
        <a href="{{ route('admin.report') }}">
          <i class="now-ui-icons users_single-02"></i>
          <p> {{ __("Report") }} </p>
        </a>
      </li>
      @endif

    </ul>
  </div>
</div>
