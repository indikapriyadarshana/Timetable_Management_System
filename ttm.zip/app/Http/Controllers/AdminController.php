<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\Role;
use App\Models\TimeTable;



class AdminController extends Controller
{
    //
    private function userReport(){
        $count = DB::select(DB::raw('select r.slug, count(u.name) as count from users u, roles r where u.role_id = r.id group by r.slug'));
        return $count;
    }  
    
    private function lectureReport() {
        $role = Role::where('name', 'lecture')->first();
        // $data = [];
        // foreach ($role->users as $lecture) {
        //     //return $lecture;
        //     $data[] = ['lecture_id' => $lecture->id, 'lecture_name' => $lecture->name, 'count' => 0];
        // }

        $tables = TimeTable::all();
        $data = [];

        foreach ($tables as $table) {
            $tblinfo = json_decode($table->table_info);
            foreach($tblinfo as $key => $value) {
                foreach($value as $time) {
                    if ($time->lecture_id !== 0) {
                        //$lectures = User::where('role_id', $role->id);
                        $lecture = User::where('id', $time->lecture_id)->first();
                        if (isset($data[$time->lecture_id])) {
                            $data[$time->lecture_id]['count'] = $data[$time->lecture_id]['count'] + 1;
                        } else {
                            if (!empty($lecture)){
                                $data[$time->lecture_id] = ['name' => $lecture->name, 'count' => 1];
                            }
                            
                        }
                        
                    }
                }
            }
        }
        return $data;
    }
    public function report() {
        $this->authorize('allowed-users', [['admin']]);
        
        $userreport = $this->userReport();
        $lecturereport = $this->lectureReport(); 
        //return $this->lectureReport();
        $data = ['userreport' => $userreport, 'lecturereport' => $lecturereport];
        return view('admin.report', compact('data'));
        //return $lecturereport;
    }
}
