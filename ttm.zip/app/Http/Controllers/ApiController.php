<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Department;
use App\Models\Course;
use App\Models\Subject;

class ApiController extends Controller
{
    //
    public function departments() {
        $departments = Department::all();
        return $departments;
    }

    public function courses($id) {
        $courses = Department::where('id', $id)->first()->courses;
        return ['courses' => $courses];
    }
}
