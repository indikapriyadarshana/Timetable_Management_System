<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Role;
use App\Models\TimeTable;
use App\Models\Department;

use PDF;
class LectureController extends Controller
{
    //
    public function show($id)
    {
        //
        //$this->authorize('allowed-users', [['lecture']]);

        $user = User::where('id', $id)->first();
        if (!empty($user) && $user->role->name == 'lecture') {
            $data = [
                'name' => $user->name,
                'email' => $user->email,
                'phone_no' => $user->phone_no
            ];

            return $data;
        } else {
            return ['error' => 'not found'];
        }

    }

    private function getTableData(TimeTable $table, $tbl_data) {
        $temp = $tbl_data;
        $tblinfo = json_decode($table->table_info);
        $data = [];
        foreach($tblinfo as $key => $value) {
            foreach($value as $time) {
                if ($time->lecture_id === auth()->user()->id) {
                    //return $time->lecture_id;
                    $temp[$key] =  $temp[$key] + 1;
                    $temp['total'] = $temp['total'] + 1;
                }
            }
        }
        return $temp;
    }

    private function horizatoalTable() {
        $table = []; 
        for ($i=6; $i < 24; $i++) {
            $data = ['time' => $i, 'lecture_id' => 0, 'subject_id' => 0, 'subject_code' => 'empty', 'hall_id' => 0, 'hall_code' => 'empty'];
            $table[] = ['monday' => $data, 'tuesday' => $data, 'wendsday' => $data, 'thursday' => $data, 'friday' => $data, 'saturday' => $data, 'sunday' => $data];
        }
        return $table;
    }

    private function test_func(TimeTable $table, $lec_tbl) {       
        $tblinfo = json_decode($table->table_info);
        $temp = $lec_tbl;
        $data = [];
        foreach($tblinfo as $key => $value) {
            foreach($value as $key2 => $value2) {
                if ($value2->lecture_id === auth()->user()->id) {
                    $course = $table->course;
                    $dep = $course->department;
                    $obj = ['course_name' => $course->course_code, 'department_name' => $dep->name, 'time' => $value2->time, 'lecture_id' => $value2->lecture_id, 'subject_id' => $value2->subject_id, 'subject_code' => $value2->subject_code, 'hall_id' => $value2->hall_id, 'hall_code' => $value2->hall_code];
                    $temp[$key2][$key] = $obj;
                    //$data[] = $key2;
                }   
                //$data[] = $key2;
            }
            
        }

        return $temp;
    }


    public function summaryReport() {
        $this->authorize('allowed-users', [['lecture']]);
        $data = [];

        $departments = Department::all();
        foreach ($departments as $department) {
            $data[$department->id] = ['name' => $department->name, 'id' => $department->id, 'reprot_data' => []];
            $days = ['monday' => 0, 'tuesday' => 0, 'wendsday' => 0, 'thursday' => 0, 'friday' => 0, 'saturday' => 0, 'sunday' => 0, 'total' => 0];
            $courses = $department->courses;
            foreach ($courses as $course) {
                $timetables = $course->timetable;
                foreach ($timetables as $timetable) {
                    $days = $this->getTableData($timetable, $days);     
                }  
            }
            $data[$department->id]['report_data'] = $days;
        }
        $name = auth()->user()->name;
        return view('lecture.summaryreport',  ['departments' => $data, 'lec_name' => $name]);
    }
    
    private function createReport() {
        $lecturetbl = $this->horizatoalTable();

        $departments = Department::all();
        foreach ($departments as $department) {       
            $courses = $department->courses;
            foreach ($courses as $course) {
                $timetables = $course->timetable;
                foreach ($timetables as $timetable) {
                    if ($timetable !== null) {
                        $lecturetbl = $this->test_func($timetable, $lecturetbl);
                    }    
                }  
            }
        }

        return $lecturetbl;
    }

    public function report() {
        $this->authorize('allowed-users', [['lecture']]);
        
        $lecturetbl = $this->createReport();
        $name = auth()->user()->name;
        return view('lecture.report',  ['lecture_tbl' => $lecturetbl, 'lec_name' => $name]);
    }

    public function tables() {
        $this->authorize('allowed-users', [['lecture']]);

        $departments = Department::all();
        return view('timetable.tables', ['departments' => $departments]);
    }

    public function download() {
        $this->authorize('allowed-users', [['lecture']]);
        
        $lecturetbl = $this->createReport();
        $pdf = PDF::loadView('lecture.report',  ['lecture_tbl' => $lecturetbl]);
        return $pdf->download('pdf_file.pdf');
    }


}
