<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Role;
use App\Models\Department;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;


class UserController extends Controller
{

    public function __construct(){ 
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $this->authorize('allowed-users', [['admin']]);

        $roles = Role::all()->whereNotIn('name', 'student');
        $departments = Department::all();
        $data = [];
        foreach ($roles as $role) {
            $data[] = [
                "id" => $role->id,
                "name" => $role->name, 
                "slug" => $role->slug, 
                "users" => $role->users,
            ];
        }

       //return $data;
        return view('user.index',[ "data" => $data,"roles"=>$roles,"departments"=> $departments ]);
        //send user data roll wise
    }

    public function profile() {
        return view('profile.edit');
    }

    public function updatePassword(Request $request, User $user) {

        //return $request->input('current_password');
        $validated = $request->validate([
            'current_password' => ['required', 'string'],
            'password' => ['required', 'confirmed', Password::min(8)],
        ]);

        if (!Hash::check($request->input('current_password'), $user->password)) {
            //$validated->errors()->add('current_password', __('The provided password does not match your current password.'));
            throw ValidationException::withMessages(['current_password' => 'The provided password does not match your current password.']);
        }

        auth()->user()->forceFill([
            'password' => Hash::make($request->input('password')),
        ])->save();

        return redirect()->back()->with('password_status', 'Password Has been updated!');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $this->authorize('allowed-users', [['admin']]);

        $departments = Department::all();
        $roles = Role::all();

        $data = [];
        foreach ($roles as $role) {
            $data[] = [
                "id" => $role->id,
                "name" => $role->name, 
                "slug" => $role->name, 
                "users" => $role->users,
            ];
        }
        return view('user.create')->with(['departments' => $departments, 'roles' => $data]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $this->authorize('allowed-users', [['admin']]);
       
        $user =  new User();
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'address' => ['required', 'string', 'max:255'],
            'phone_no' => ['required', 'string', 'max:12'],
            'email' => [
                'required',
                'string',
                'email',
                'max:255',
                Rule::unique(User::class),
            ],
            'role_id' => ['required', 'numeric'],
            'department_id' => ['required', 'numeric'],
            'password' => ['required', 'confirmed', 'min:8']
        ]);
        User::create([
            'role_id' => $request->input('role_id'),
            'department_id' => $request->input('department_id'),
            'name' => $request->input('name'),
            'address' => $request->input('address'),
            'phone_no' => $request->input('phone_no'),
            'email' => $request->input('email'),
            'password' => Hash::make($request->input('password')),
        ]);

        //$user->create($request->all());
        return redirect()->route('user.index')->with('status', 'User has been created!');
        //return response()->json("dfsdf");

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        $this->authorize('allowed-users', [['admin']]);

        return view('user.show', ['data' => $user]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        //
        $this->authorize('allowed-users', [['admin']]);

        return view('user.edit', ['user' => $user]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        //
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'address' => ['required', 'string', 'max:255'],
            'phone_no' => ['required', 'string', 'max:12'],
            'email' => [
                'required',
                'string',
                'email',
                'max:255',
            ],
        ]);

        $user->update($request->all());
        return redirect()->back()->with('status', 'User Has been updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        //
    }

    public function dashboard() {
        //$user = Auth::user();
        // $role = $user->role->name;

        // if ($role === "student") {
        //     return redirect('/student/dashboard');
        // } else if ($role === "admin") {
        //     return redirect('/admin/dashboard');
        // } else if ($role === "lecture") {
        //     return redirect('/lecture/dashboard');
        // } else if ($role === "lecture") {
        //     return redirect('/keeper/dashboard');
        // }
        return view('dashboard');
    }
}
