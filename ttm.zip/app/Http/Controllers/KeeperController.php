<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\LectureHall;
use App\Models\Department;
use App\Models\TimeTable;
use App\Models\User;

class KeeperController extends Controller
{
    //
    private function horizatoalTable() {
        $table = []; 
        for ($i=6; $i < 24; $i++) {
            $data = ['time' => $i, 'lecture_id' => 0, 'subject_id' => 0, 'subject_code' => '-', 'hall_id' => 0, 'hall_code' => '-'];
            $table[] = ['monday' => $data, 'tuesday' => $data, 'wendsday' => $data, 'thursday' => $data, 'friday' => $data, 'saturday' => $data, 'sunday' => $data];
        }
        return $table;
    }

    private function filterTimetableByHall(TimeTable $table, $lec_tbl, $hall_code) {       
        $tblinfo = json_decode($table->table_info);
        $temp = $lec_tbl;
        $data = [];
        foreach($tblinfo as $key => $value) {
            foreach($value as $key2 => $value2) {
                if (  $value2->lecture_id !== 0 && $value2->hall_code === $hall_code) {
                    $course = $table->course;

                    $lecture = User::where('id', $value2->lecture_id)->first();
                    $dep = $course->department;
                    $obj = ['lecture_name' => $lecture->name, 'course_name' => $course->course_code, 'department_name' => $dep->name, 'time' => $value2->time, 'lecture_id' => $value2->lecture_id, 'subject_id' => $value2->subject_id, 'subject_code' => $value2->subject_code, 'hall_id' => $value2->hall_id, 'hall_code' => $value2->hall_code];
                    $temp[$key2][$key] = $obj;
                    //$data[] = $key2;
                }   
                //$data[] = $key2;
            }
            
        }

        return $temp;
    }

    private function getSubjectCountByHallcode(TimeTable $table, $hall_code) {       
        $tblinfo = json_decode($table->table_info);
        $data = [];
        foreach($tblinfo as $key => $value) {
            foreach($value as $key2 => $value2) {
                if ($value2->hall_code === $hall_code && $value2->subject_code != '-') {
                    array_push($data, $value2->subject_code);
                }
            }
            
        }

        return count($data);
    }

    public function subject_report($hall_code) {
       $dep_id = LectureHall::where('hall_code', $hall_code)->first()->department_id;
       $department = Department::where('id', $dep_id)->first();

        $halls = [];  
        $courses = $department->courses;
        
        foreach ($courses as $course) {
            $timetables = $course->timetable;
            $count = 0;
            foreach ($timetables as $timetable) {
                if ($timetable !== null) {
                    $result = $this->getSubjectCountByHallcode($timetable, $hall_code);
                    $count = $count + $result;
                }    
            }  
            $g = ["hall_code" => $hall_code, "course_name" => $course->name, "count" => $count];
            array_push($halls, $g);
        }

        return $halls;
    }

    public function report() {
        $this->authorize('allowed-users', [['hall_keeper']]);

        $lecturetbl = $this->horizatoalTable();
        $halls = LectureHall::all();
    
        $departments = Department::all();
        $data = [];
        foreach ($departments as $department) {
            $courses = $department->lectureHalls;
            //$temp = ['course_name' => $course->name, 'course_id' => $course->id];
            $data[$department->id] = ['name' => $department->name, 'id' => $department->id, 'halls' => $courses->toArray()];
        }
        
        return view('keeper.report')->with(['departments' => $data]);
        //$tt = TimeTable::where('id', 16)->first();


        
    }

    private function keeper_report($hall_id, $hall_code) {
        $tbl = $this->horizatoalTable();
        
        $departments = Department::all();
        foreach ($departments as $department) {       
            $courses = $department->courses;
            foreach ($courses as $course) {
                $timetables = $course->timetable;
                foreach ($timetables as $timetable) {
                    if ($timetable !== null) {
                        $tbl = $this->filterTimetableByHall($timetable, $tbl, $hall_code);
                    }    
                }  
            }
        }

        return $tbl;
    }
//report generate
    public function generate(Request $request) {

        $this->authorize('allowed-users', [['hall_keeper']]);

        $validated = $request->validate([
            'hall_id' => ['required', 'numeric'],
            'keeper_table' => ['required'],
        ]);

        $departments = Department::all();
        $data = [];
        foreach ($departments as $department) {
            $courses = $department->lectureHalls;
            $data[$department->id] = ['name' => $department->name, 'id' => $department->id, 'halls' => $courses->toArray()];
        }

        $hall = LectureHall::where('id', $request->input('hall_id'))->first();

        if ($request->input('keeper_table') === "keeper_table") {
            $tbl = $this->keeper_report($request['hall_id'], $hall->hall_code);
            return view('keeper.report')->with(['departments' => $data, 'tbl' => $tbl, 'report_title' => 'Timetable ' . $hall->hall_code]);
        } else if ($request->input('keeper_table') === "subject_report") {
            $subject_report = $this->subject_report($hall->hall_code);
            //return response()->json($subject_report[0]);
            return view('keeper.report')->with(['departments' => $data, 'subject_report' => $subject_report, 'report_title' => 'Subject Report for hall ' . $hall->hall_code]);
        }
    
    }
}
