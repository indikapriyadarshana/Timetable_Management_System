<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\Department;
use App\Models\TimeTable;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    private function create_table () {
        $time = [];
        $pre_time = 0;
        $next_time = 1;
        for ($i = 6; $i < 24; $i++) {
            $data = ['time' => $i, 'lecture_id' => 0, 'subject_id' => 0, 'subject_code' => 'empty', 'hall_id' => 0, 'hall_code' => 'empty'];
            $pre_time++;
            $next_time++;
            $time[] = $data;
        }
        $days = ['monday' => $time, 'tuesday' => $time, 'wendsday' => $time, 'thursday' => $time, 'friday' => $time, 'saturday' => $time, 'sunday' => $time];

        return $days;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->authorize('allowed-users', [['admin']]);
        //
        $departments = Department::all();
        return view('course.index', ["departments" => $departments]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $this->authorize('allowed-users', [['admin']]);
        return view('course.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $this->authorize('allowed-users', [['admin']]);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:150'],
            'details' => ['required', 'string', 'max:100'],
            'course_code' => ['required', 'string', 'max:50'],
            'department_id' => ['required', 'numeric'],
            'semester' => ['required', 'numeric'],
        ]);
        
        $course = Course::create($request->all());
        //return response()->json($request->all);

        $table = $this->create_table();

        for ($i = 1; $i <= $request->input('semester'); $i++) {
            $timetable = ['semester' => $i, 'table_info' => json_encode($table), 'course_id' => $course->id];
            TimeTable::create($timetable);
        }
        
        return redirect()->route('courses.index')->with('status', 'Course has been created!');
        //return response()->json(TimeTable::all());

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function show(Course $course)
    {
        //
        $this->authorize('allowed-users', [['admin']]);
        return view('course.show', ["data"=>$course]);
        //return response()->json($course);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function edit(Course $course)
    {
        //
        $this->authorize('allowed-users', [['admin']]);
        return view('course.edit', ["data"=>$course]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Course $course)
    {
        //
        $this->authorize('allowed-users', [['admin']]);
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:150'],
            'details' => ['required', 'string', 'max:100'],
            'course_code' => ['required', 'string', 'max:50'],
            'department_id' => ['required', 'numeric'],
        ]);
        
        $course->update($request->all());
        return redirect()->route('courses.edit', $course->id)->with('status', 'Course has been updated!');
        //return response()->json($data);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function destroy(Course $course)
    {
        //
    }
}
