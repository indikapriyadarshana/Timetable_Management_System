<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\TimeTable;
use App\Models\User;


class StudentController extends Controller
{
    //
    private function horizatoalTable() {
        $table = []; 
        for ($i=6; $i < 24; $i++) {
            $data = ['time' => $i, 'lecture_id' => 0, 'subject_id' => 0, 'subject_code' => 'empty', 'hall_id' => 0, 'hall_code' => 'empty'];
            $table[] = ['monday' => $data, 'tuesday' => $data, 'wendsday' => $data, 'thursday' => $data, 'friday' => $data, 'saturday' => $data, 'sunday' => $data];
        }
        return $table;
    }

    private function test_func(TimeTable $table, $lec_tbl) {       
        $tblinfo = json_decode($table->table_info);
        $temp = $lec_tbl;
        $data = [];
        foreach($tblinfo as $key => $value) {
            foreach($value as $key2 => $value2) {
                if (  $value2->lecture_id !== 0 ) {
                    $course = $table->course;
                    $lecture = User::where('id', $value2->lecture_id)->first();
                    if (!empty($lecture)) {
                        $dep = $course->department;
                        $obj = ['lecture_name' => $lecture->name, 'course_name' => $course->course_code, 'department_name' => $dep->name, 'time' => $value2->time, 'lecture_id' => $value2->lecture_id, 'subject_id' => $value2->subject_id, 'subject_code' => $value2->subject_code, 'hall_id' => $value2->hall_id, 'hall_code' => $value2->hall_code];
                        $temp[$key2][$key] = $obj;
                    }
                    
                }
                    //$data[] = $key2;
                //$data[] = $key2;
            }
            
        }

        return $temp;
    }

    public function report($id) {

        $this->authorize('allowed-users', [['student']]);

        $table = TimeTable::where('id', $id)->first();
        if (empty($table)) abort(404);

        $hz_table = $this->horizatoalTable();
        $timetable = $this->test_func($table, $hz_table);
        $name = auth()->user()->name;

        return view('student.report', ['data' => $timetable, 'student_name' => $name]);
    }
}
