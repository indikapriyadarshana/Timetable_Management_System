<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\LectureHall;
use App\Models\Department;


class LectureHallController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $this->authorize('allowed-users', [['admin']]);
        $departments = Department::all();
        return view('lecturehall.index', ['departments' => $departments]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $this->authorize('allowed-users', [['admin']]);


        $validated = $request->validate([
            'hall_code' => ['required', 'string', 'max:50'],
            'department_id' => ['required', 'numeric', 'max:255'],
        ]);

        $hall_code = $request->input('hall_code');
        $department_id = $request->input('department_id');
        
        LectureHall::create([
            'hall_code' => $hall_code,
            'department_id' => $department_id
        ]);
        return redirect()->route('lecturehall.index')->with('status', 'Lecture Hall has been created!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $this->authorize('allowed-users', [['admin']]);

        $lecturehall = LectureHall::where('id', $id)->first();
        if (!isset($lecturehall)) {
            return abort(404);
        } else {
            return view('lecturehall.edit', ['data' => $lecturehall]);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //

        $this->authorize('allowed-users', [['admin']]);
        
        $lecturehall = LectureHall::where('id', $id)->first();
        if (!isset($lecturehall)) {
            return abort(404);
        } else {
            $validated = $request->validate([
                'hall_code' => ['required', 'string', 'max:255'],
            ]);
            
            $lecturehall->update($request->all());
            return redirect()->route('lecturehall.edit', $id)->with('status', 'Lecture Hall has been updated!');    
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
