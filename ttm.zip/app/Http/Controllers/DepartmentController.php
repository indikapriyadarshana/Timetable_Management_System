<?php

namespace App\Http\Controllers;

use App\Models\Department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class DepartmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $this->authorize('allowed-users', [['admin']]);

        $data = Department::all();
        return view('department.index', ["data" => $data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $this->authorize('allowed-users', [['admin']]);

        $departments = Department::all();
        $data = [];
        foreach ($departments as $department) {
            $courses = $department->courses;
            //$temp = ['course_name' => $course->name, 'course_id' => $course->id];
            $data[$department->id] = ['department_name' => $department->name, 'department_id' => $department->id, 'courses' => $courses->toArray()];
        }
        return view('department.create', ['data' => $data]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $this->authorize('allowed-users', [['admin']]);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:250'],
            'details' => ['required', 'string', 'max:100'],
            'dept_code' => ['required', 'string', 'max:30']
        ]);
        
        Department::create($request->all());
        return redirect()->route('department.index')->with('success', 'Departmenet has been created!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function show(Department $department)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function edit(Department $department)
    {
        $this->authorize('allowed-users', [['admin']]);
        return view('department.edit', ["data"=>$department]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Department $department)
    {
        //
        $this->authorize('allowed-users', [['admin']]);
        
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:250'],
            'details' => ['required', 'string', 'max:100'],
            'dept_code' => ['required', 'string', 'max:30']
        ]);

        $department->update($request->all());
        return redirect()->route('department.index')->with('success', 'Departmenet has been updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function destroy(Department $department)
    {
        //
    }
}
