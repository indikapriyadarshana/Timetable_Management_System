<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TimeTable;
use App\Models\Department;
use App\Models\Course;


use App\Events\TimeTableEvent;

class TimeTableController extends Controller
{
    private function create_table () {
        $time = [];
        $pre_time = 0;
        $next_time = 1;
        for ($i = 6; $i < 24; $i++) {
            $data = ['allocated' => "false"];
            $pre_time++;
            $next_time++;
            $time[] = $data;
        }
        $days = ['monday' => $time, 'tuesday' => $time, 'wendsday' => $time, 'thursday' => $time, 'friday' => $time, 'saturday' => $time, 'sunday' => $time];

        return $days;
    }

    private function test_func(TimeTable $table, $lec_tbl) {       
        $tblinfo = json_decode($table->table_info);
        $temp = $lec_tbl;
        $data = [];
        foreach($tblinfo as $key => $value) {
            foreach($value as $key2 => $value2) {
                if ($value2->lecture_id === auth()->user()->id) {
                    $temp[$key][$key2]['allocated'] = "true";
                }
                //$data[] = $key2;
            }
            
        }

        return $temp;
    }

    private function create_lecture_tbl() {
        $lecturetbl = $this->create_table();

        $departments = Department::all();
        foreach ($departments as $department) {       
            $courses = $department->courses;
            foreach ($courses as $course) {
                $timetables = $course->timetable;
                foreach ($timetables as $timetable) {
                    if ($timetable !== null) {
                        $lecturetbl = $this->test_func($timetable, $lecturetbl);
                    }    
                }  
            }
        }

        return $lecturetbl;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $role = auth()->user()->role->name;
        if ($role == "student") {
            //$course = Course::where('id', auth()->user()->courses_id)->first();
            $tables = TimeTable::where('course_id', auth()->user()->courses_id)->get();
            //return $tables;

            //return $yy;
            //$departments = Department::where('id', auth()->user()->department_id);
            return view('timetable.st_table', ['tables' => $tables]);
        }

        $departments = Department::all();
        return view('timetable.tables', ['departments' => $departments]);
    }

    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $table = TimeTable::where('id', $id)->first();
        $user = ['user_id' => auth()->user()->id, 'user_role' => auth()->user()->role->name, 'table_id' => $id, 'course_name' => $table->course->name, 'semester' => $table->semester];
        return view('timetable.show')->with(['table' => $table->table_info, 'user' => json_encode($user)]);
        //return response()->json($table);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $this->authorize('allowed-users', [['lecture', 'hall_keeper']]);

        $lec_tbl = $this->create_lecture_tbl();
        //return response()->json($tbll); 

        $table = TimeTable::where('id', $id)->first();
        $subjects = $table->course->subjects;
        $lecturehalls = $table->course->department->lectureHalls;
        $user = ['user_id' => auth()->user()->id, 'user_role' => auth()->user()->role->name, 'table_id' => $id, 'course_name' => $table->course->name, 'semester' => $table->semester];

        return view('timetable.edit')->with(['table' => $table->table_info, 'subjects' => $subjects, 'lecturehalls' => $lecturehalls, 'user' => json_encode($user), 'lecturetable' => json_encode($lec_tbl) ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $this->authorize('allowed-users', [['lecture', 'hall_keeper']]);
           
        $table = TimeTable::where('id', $id)->first();
        $t = json_encode($request->input('table_info'));
        $table->update(array('table_info' => $t));
        broadcast(new TimeTableEvent($table))->toOthers();
        return response()->json('ok', 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
