<?php

namespace App\Actions\Fortify;

use Laravel\Fortify\Rules\Password;

trait PasswordValidationRules
{
    /**
     * Get the validation rules used to validate passwords.
     *
     * @return array
     */
    protected function passwordRules()
    {
        return ['required', 'string', new Password, 'confirmed'];
    }
}
/**
     * Get the validation rules used to validate passwords.
     *
     * @return array
     * Minimum eight characters, at least one letter and one number:

*"^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$"
*Minimum eight characters, at least one letter, one number and one special character:

*"^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$"
*Minimum eight characters, at least one uppercase letter, one lowercase letter and one number:

*"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$"
*Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character:

*"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$"
*Minimum eight and maximum 10 characters, at least one uppercase letter, one lowercase letter, one number and one special character:

*"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,10}$"


*This regex will enforce these rules:

*At least one upper case English letter, (?=.*?[A-Z])
*At least one lower case English letter, (?=.*?[a-z])
*At least one digit, (?=.*?[0-9])
*At least one special character, (?=.*?[#?!@$%^&*-])
*Minimum eight in length .{8,} (with the anchors)
     */