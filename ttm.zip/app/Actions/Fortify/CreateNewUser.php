<?php

namespace App\Actions\Fortify;

use App\Models\User;
use App\Models\Role;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Laravel\Fortify\Contracts\CreatesNewUsers;

class CreateNewUser implements CreatesNewUsers
{
    use PasswordValidationRules;

    /**
     * Validate and create a newly registered user.
     *
     * @param  array  $input
     * @return \App\Models\User
     */
    public function create(array $input)
    {
        Validator::make($input, [
            'name' => ['required', 'string', 'max:255'],
            'address' => ['required', 'string', 'max:255'],
            'phone_no' => ['required', 'string', 'regex:/(\+94)[0-9]{9}/', 'max:12'],
            'email' => [
                'required',
                'string',
                'email',
                'max:255',
                Rule::unique(User::class),
            ],
            'department_id' => ['required', 'numeric'],
            'courses_id' => ['required', 'numeric'],
            'password' => $this->passwordRules(),
        ])->validate();

        $role = Role::where('name', 'student')->first();

        return User::create([
            'role_id' => $role->id,
            'department_id' => $input['department_id'],
            'courses_id' => $input['courses_id'],
            'name' => $input['name'],
            'address' => $input['address'],
            'phone_no' => $input['phone_no'],
            'email' => $input['email'],
            'password' => Hash::make($input['password']),
        ]);
    }
}
