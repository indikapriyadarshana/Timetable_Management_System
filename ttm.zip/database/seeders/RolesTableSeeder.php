<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Schema;
use App\Models\Role;

class RolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Schema::disableForeignKeyConstraints();
        Role::truncate();
        Schema::enableForeignKeyConstraints();

        Role::create(['name' => 'admin', 'slug' => 'Admin']);
        Role::create(['name' => 'student', 'slug' => 'Student']);
        Role::create(['name' => 'lecture', 'slug' => 'Lecture']);
        Role::create(['name' => 'hall_keeper', 'slug' => 'Hall Keeper']);
    }
}
