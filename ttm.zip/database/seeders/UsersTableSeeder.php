<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;
use App\Models\Role;
use App\Models\User;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Schema::disableForeignKeyConstraints();
        User::truncate();
        Schema::enableForeignKeyConstraints();
    
        User::create([
            "name" => "Admin user",
            "role_id" => "1",
            "department_id" => "1",
            "email" => "admin@university.com",
            "address" => "colombo",
            "phone_no" => "0896457869",
            "password" => Hash::make('admin12345')
        ]);

    }
}
