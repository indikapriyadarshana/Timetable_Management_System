<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Schema;
use App\Models\Course;
use App\Models\Department;

class CourseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Schema::disableForeignKeyConstraints();
        Course::truncate();
        Schema::enableForeignKeyConstraints();

        $science = Department::where('dept_code', 'DEP_SCIENCE')->first();
        $max = Department::where('dept_code', 'DEP_MAX')->first();
        $it = Department::where('dept_code', 'DEP_IT')->first();


    
        Course::create([
            "name" => "Physics Course",
            "details" => "Physics Course",
            "course_code" => "COURSE_PHYSICS",
            "department_id" => $science->id,
        ]);

        Course::create([
            "name" => "Probability Course",
            "details" => "Probability Course",
            "course_code" => "COURSE_PROBABILITY",
            "department_id" => $max->id,
        ]);

        Course::create([
            "name" => "Network Course",
            "details" => "Network Course",
            "course_code" => "COURSE_NETWORK",
            "department_id" => $it->id,
        ]);
    }
}
