<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Schema;
use App\Models\Department;


class DepartmentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Schema::disableForeignKeyConstraints();
        Department::truncate();
        Schema::enableForeignKeyConstraints();
    
        Department::create([
            "name" => "Science Department",
            "details" => "Departement of Science",
            "dept_code" => "DEP_SCIENCE",
        ]);

        Department::create([
            "name" => "Max Department",
            "details" => "Departement of Mathematics",
            "dept_code" => "DEP_MAX",
        ]);

        Department::create([
            "name" => "IT Department",
            "details" => "Departement of IT",
            "dept_code" => "DEP_IT",
        ]);
    }
}
