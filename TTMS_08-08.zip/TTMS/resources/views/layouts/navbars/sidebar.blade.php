<div class="sidebar" data-color="orange">
  <!--
    Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
-->
  <div class="logo">
    <a href="" class="simple-text logo-mini">
    <i class="now-ui-icons users_circle-08"></i>
    </a>
    <a href="" class="simple-text logo-normal">
      {{ auth()->user()->role->slug }}
    </a>
  </div>
  <div class="sidebar-wrapper" id="sidebar-wrapper">
    <ul class="nav">
      <li class="">
        <a href="">
          <i class="now-ui-icons design_app"></i>
          <p>{{ __('Dashboard') }}</p>
        </a>
      </li>
      <li>
      
      @if (auth()->user()->role->name !== "admin")
      <li class="">
        <a href="">
          <i class="now-ui-icons education_atom"></i>
          <p>{{ __('Time Table') }}</p>
        </a>
      </li>
      @endif

      <li class="">
        <a href="{{ route('user.index') }}">
          <i class="now-ui-icons users_single-02"></i>
          <p> {{ __("User Profile") }} </p>
        </a>
      </li>

      @if (auth()->user()->role->name === "admin")
      <li class="">
        <a href="{{ route('courses.index') }}">
          <i class="now-ui-icons users_single-02"></i>
          <p> {{ __("Courses") }} </p>
        </a>
      </li>
      @endif

      @if (auth()->user()->role->name === "admin")
      <li class="">
        <a href="{{ route('department.index') }}">
          <i class="now-ui-icons users_single-02"></i>
          <p> {{ __("Department") }} </p>
        </a>
      </li>
      @endif

    </ul>
  </div>
</div>
