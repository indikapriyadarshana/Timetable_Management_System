<footer class="footer">
  <div class=" container-fluid ">
    <div class="copyright" id="copyright">
      &copy;
      <script>
        document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))
      </script>, Timetable Management System

    </div>
  </div>
</footer>