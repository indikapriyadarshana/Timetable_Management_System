@extends('layouts.app', [
'namePage' => 'Dashboard',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
])

@section('content')
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">



  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h3>{{$course->code}} - {{$course->name}}</h3>
          <h5 class="title"> {{__(" Subject")}}</h5>
        </div>
        <div class="card-body">
          @foreach ($data as $subject)
          <div class="d-flex justify-content-between">
            <h5>{{$subject->code}} - {{$subject->name}}</h5>
            <a class="btn btn-primary btn-round" href="{{ route('subjects.edit',$subject->id) }}">Edit</a>
          </div>
          @endforeach
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="card card-user">
      <div class="card-header">
        <h5 class="title">{{__(" Add New Subject")}}</h5>
      </div>
      <div class="card-body">
        <form method="post" action="{{ route('subjects.store') }}" autocomplete="off" enctype="multipart/form-data">
          @csrf
          @include('alerts.success')
          <div class="row">
          </div>
          <div class="row">
            <div class="col-md-7 pr-1">
              <div class="form-group">
                <label>{{__(" Name")}}</label>
                <input type="text" name="name" class="form-control" value="">
                @include('alerts.feedback', ['field' => 'name'])
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-7 pr-1">
              <div class="form-group">
                <label>{{__(" Subject Code")}}</label>
                <input type="text" name="subject_code" class="form-control" value="">
                @include('alerts.feedback', ['field' => 'subject_code'])
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-7 pr-1">
              <div class="form-group">
                <label>{{__(" Semester")}}</label>
                <input type="text" name="semester" class="form-control" value="">
                @include('alerts.feedback', ['field' => 'semester'])
              </div>
            </div>
          </div>
          <input type="hidden" name="course_id" value="{{$course->id}}">
          <div class="card-footer ">
            <button type="submit" class="btn btn-primary btn-round">{{__('Add Subject')}}</button>
          </div>
          <hr class="half-rule" />
        </form>
      </div>
    </div>
  </div>
</div>

</div>
@endsection
@push('js')
<script>
  $(document).ready(function() {
    // Javascript method's body can be found in assets/js/demos.js
    demo.initDashboardPageCharts();

  });
</script>
@endpush