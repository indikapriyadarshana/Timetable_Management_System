@extends('layouts.app', [
'namePage' => 'Dashboard',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
])

@section('content')
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row justify-content-md-center">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h2 class="title text-center">{{__(" Welcome")}}</h2>
        </div>
        <div class="card-body">
            <h4 class="text-center">Time Table Management System </h4>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus totam excepturi repellat ab. Culpa vel hic quis reiciendis dignissimos libero laudantium aut, excepturi rem pariatur minus, harum deserunt eaque molestias.</p>
            <h6>If you face any system issue please contact ICT center +941109865712</h6>
        </div>
      </div>
    </div>
  </div>

</div>
@endsection
@push('js')
<script>
  $(document).ready(function() {
    // Javascript method's body can be found in assets/js/demos.js
    demo.initDashboardPageCharts();

  });
</script>
@endpush