@extends('layouts.app', [
'namePage' => 'Dashboard',
'class' => 'login-page sidebar-mini ',
'activePage' => 'home',
'backgroundImage' => asset('now') . "/img/bg14.jpg",
])

@section('content')
<div class="panel-header panel-header-lg">
  <!--<canvas id="bigDashboardChart"></canvas>  "-->
</div>
<div class="content">
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h5 class="title">{{__(" Courses")}}</h5>
        </div>
        <div class="card-body">
          <div id="accordion">
            @foreach ($data as $department)
            <div class="card">
              <div class="card-header" id="headingOne">
                <h5 class="mb-0">
                  <button class="btn btn-link" data-toggle="collapse" data-target="#collapse{{$department['department_id']}}" aria-expanded="true" aria-controls="collapse{{$department['department_id']}}">
                    {{$department['department_name']}}
                  </button>
                </h5>
              </div>

              <div id="collapse{{$department['department_id']}}" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                <div class="card-body">
                  <h6>Add New Course</h6>
                  <form method="post" action="{{route('courses.store')}}" autocomplete="off" enctype="multipart/form-data">
                    @csrf
                    @include('alerts.success')
                    <div class="row">
                    </div>
                    <div class="row">
                      <div class="col-md-7 pr-1">
                        <div class="form-group">
                          <label>{{__("Course Name")}}</label>
                          <input type="text" name="name" class="form-control" value="">
                          @include('alerts.feedback', ['field' => 'name'])
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-7 pr-1">
                        <div class="form-group">
                          <label>{{__(" Course Code")}}</label>
                          <input type="text" name="course_code" class="form-control" value="">
                          @include('alerts.feedback', ['field' => 'course_code'])
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-7 pr-1">
                        <div class="form-group">
                          <label>{{__(" Course Details")}}</label>
                          <textarea name="details" class="form-control" value=""></textarea>
                          @include('alerts.feedback', ['field' => 'details'])
                        </div>
                      </div>
                    </div>
                    <input type="hidden" name="department_id" value="{{$department['department_id']}}">
                    <div class="card-footer ">
                      <button type="submit" class="btn btn-primary btn-round">{{__('Add Course')}}</button>
                    </div>
                    <hr class="half-rule" />
                  </form>
                  @foreach ($department['courses'] as $course)
                  <div class="d-flex justify-content-between">
                    <h6>{{$course->name}}</h6>
                    <div class="d-flex justify-content-between">
                      <a class="btn btn-primary btn-round" href="{{ route('courses.edit', $course->id) }}">Edit</a>
                      <a class="btn btn-primary btn-round" href="{{ route('subjects.show', $course->id) }}">Manage Subjects</a>
                    </div>  
                  </div>
                  @endforeach
                </div>
              </div>
            </div>
            @endforeach
          </div>
        </div>
      </div>
    </div>
  </div>
  @endsection
  @push('js')
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });
  </script>
  @endpush