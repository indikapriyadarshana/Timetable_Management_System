<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [ 
        'name',
        'details',
        'course_code',
        'department_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'created_at',
        'updated_at',
    ];

    public function department() {
        return $this->belongsTo(Department::class, 'department_id', 'id');
        
    }

    public function timetable() {
        return $this->hasMany(TimeTable::class);
        
    }

    public function subjects() {
        return $this->hasMany(Subject::class);
    }
}
